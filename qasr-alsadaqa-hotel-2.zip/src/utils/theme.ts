export type ThemeMode = 'system' | 'light' | 'dark';
const KEY = 'qasr_theme_v1';

export const getThemeMode = (): ThemeMode => {
  try {
    const v = localStorage.getItem(KEY);
    if (v === 'light' || v === 'dark' || v === 'system') return v;
  } catch {
    /* ignore */
  }
  return 'system';
};

const systemPrefersDark = () =>
  typeof window !== 'undefined' && !!window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;

export const applyTheme = (mode: ThemeMode = getThemeMode()) => {
  const dark = mode === 'dark' || (mode === 'system' && systemPrefersDark());
  const root = document.documentElement;
  root.classList.toggle('dark', dark);
  root.style.colorScheme = dark ? 'dark' : 'light';
  const meta = document.querySelector('meta[name="theme-color"]');
  if (meta) meta.setAttribute('content', dark ? '#0a1424' : '#111e33');
};

export const setThemeMode = (mode: ThemeMode) => {
  try {
    localStorage.setItem(KEY, mode);
  } catch {
    /* ignore */
  }
  applyTheme(mode);
  window.dispatchEvent(new CustomEvent('qasr-theme-change', { detail: mode }));
};

/** Call once at startup: applies the saved mode and follows the OS setting while in "system" mode. */
export const initTheme = () => {
  applyTheme();
  if (window.matchMedia) {
    const mq = window.matchMedia('(prefers-color-scheme: dark)');
    const onChange = () => {
      if (getThemeMode() === 'system') applyTheme('system');
    };
    if (mq.addEventListener) mq.addEventListener('change', onChange);
    else if ((mq as MediaQueryList).addListener) (mq as MediaQueryList).addListener(onChange);
  }
};
