import type { Booking } from '../types/hotel';
import { localDate } from './dates';

const toDate = (s: string) => {
  const [y, m, d] = s.substring(0, 10).split('-').map(Number);
  return new Date(y, (m || 1) - 1, d || 1);
};
const daysBetween = (from: string, to: string) =>
  Math.max(1, Math.round((toDate(to).getTime() - toDate(from).getTime()) / 86400000));

const isCancelled = (b: Booking) => !b.isActive && !b.actualCheckOutDate && (b.notes || '').includes('[ملغي]');

export interface Hosting {
  totalNights: number; // nights actually hosted (completed + current stay up to today)
  stays: number;
  current?: Booking; // currently staying
  currentDays?: number;
  lastStay?: { from: string; to: string; nights: number };
}

/** "Hosting time" for a guest, computed from real bookings (cancelled ones are ignored). */
export function guestHosting(guestId: number, bookings: Booking[]): Hosting {
  const today = localDate();
  const mine = bookings.filter((b) => b.guestId === guestId && !isCancelled(b));
  let totalNights = 0;
  let current: Booking | undefined;
  let currentDays: number | undefined;
  let lastStay: Hosting['lastStay'];

  for (const b of mine) {
    const from = b.checkInDate.substring(0, 10);
    if (b.isActive) {
      current = b;
      currentDays = daysBetween(from, today);
      totalNights += currentDays;
    } else {
      const to = (b.actualCheckOutDate || b.expectedCheckOutDate).substring(0, 10);
      const n = daysBetween(from, to);
      totalNights += n;
      if (!lastStay || from > lastStay.from) lastStay = { from, to, nights: n };
    }
  }
  return { totalNights, stays: mine.length, current, currentDays, lastStay };
}
