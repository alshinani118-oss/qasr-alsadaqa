// Local-time helpers. `toISOString()` returns UTC, which shifts dates/times
// by the hotel's UTC offset (e.g. +3h in Saudi Arabia) — wrong near midnight.
const pad = (n: number) => String(n).padStart(2, '0');

export const localDate = (d: Date = new Date()): string =>
  `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;

export const localDateTime = (d: Date = new Date()): string =>
  `${localDate(d)} ${pad(d.getHours())}:${pad(d.getMinutes())}`;

export const localDateTimeSec = (d: Date = new Date()): string =>
  `${localDateTime(d)}:${pad(d.getSeconds())}`;

/** Add whole days to a 'YYYY-MM-DD' string without timezone drift. */
export const addDaysToDateStr = (dateStr: string, days: number): string => {
  const [y, m, d] = dateStr.substring(0, 10).split('-').map(Number);
  return localDate(new Date(y, (m || 1) - 1, (d || 1) + days));
};

let lastId = 0;
/** Monotonic unique numeric id (Date.now() + N collides on rapid actions). */
export const uid = (): number => {
  const now = Date.now();
  lastId = now > lastId ? now : lastId + 1;
  return lastId;
};

/** Booking code that is guaranteed not to collide with existing ones. */
export const generateBookingCode = (existing: string[]): string => {
  const taken = new Set(existing);
  for (let i = 0; i < 50; i++) {
    const code = `AZ-${Math.floor(1000 + Math.random() * 9000)}`;
    if (!taken.has(code)) return code;
  }
  return `AZ-${uid().toString().slice(-7)}`;
};
