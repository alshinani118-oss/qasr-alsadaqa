// Arabic-capable PDF generator.
// jsPDF's built-in fonts have no Arabic glyphs, so Arabic text came out as garbage.
// Here every page is drawn on a <canvas> (the browser/WebView shapes Arabic and handles RTL),
// then embedded in a jsPDF document as an image. Text is not selectable, but it always renders
// correctly offline on any device — no font files needed.
import { jsPDF } from 'jspdf';
import { saveBlob } from './saveFile';

export type PdfCell = string | number | null | undefined | CanvasImageSource;

export interface PdfColumn {
  header: string;
  /** relative width */
  width: number;
  align?: 'right' | 'center' | 'left';
}

export interface PdfSpec {
  hotelName: string;
  hotelAddress?: string;
  title: string;
  metaRight?: [string, string][];
  metaLeft?: [string, string][];
  columns?: PdfColumn[];
  rows?: PdfCell[][];
  totals?: [string, string][];
  note?: string;
  signatures?: string[];
  landscape?: boolean;
}

const FONT =
  '"Noto Naskh Arabic","Noto Sans Arabic","Droid Arabic Naskh","Segoe UI",Tahoma,Arial,sans-serif';
const NAVY = '#0f1b2d';
const GOLD = '#c9a227';
const PAPER = '#fbf8ee';
const GRID = '#e3dcc3';
const INK = '#1c2333';
const MUTED = '#6b7280';

type Ctx = CanvasRenderingContext2D;

const isImage = (c: PdfCell): c is CanvasImageSource => typeof c === 'object' && c !== null;

function wrap(ctx: Ctx, text: string, maxW: number, maxLines: number): string[] {
  const words = String(text ?? '').split(/\s+/).filter(Boolean);
  const lines: string[] = [];
  let cur = '';
  for (const w of words) {
    const test = cur ? `${cur} ${w}` : w;
    if (!cur || ctx.measureText(test).width <= maxW) cur = test;
    else {
      lines.push(cur);
      cur = w;
    }
  }
  if (cur) lines.push(cur);
  if (lines.length > maxLines) {
    lines.length = maxLines;
    lines[maxLines - 1] += '…';
  }
  return lines.length ? lines : [''];
}

export async function buildArabicPdf(spec: PdfSpec): Promise<Blob> {
  try {
    await (document as any).fonts?.ready;
  } catch {
    /* ignore */
  }

  const landscape = !!spec.landscape;
  const W = landscape ? 1754 : 1240;
  const H = landscape ? 1240 : 1754;
  const M = 70;
  const FOOT = 90;
  const printedAt = new Date().toLocaleDateString('en-GB');

  const pageImages: string[] = [];
  let canvas!: HTMLCanvasElement;
  let ctx!: Ctx;
  let y = 0;
  let pageNo = 0;

  const font = (size: number, bold = false) => `${bold ? 'bold ' : ''}${size}px ${FONT}`;

  const text = (
    t: string,
    x: number,
    yy: number,
    o: { size?: number; bold?: boolean; color?: string; align?: CanvasTextAlign } = {}
  ) => {
    ctx.font = font(o.size ?? 26, o.bold);
    ctx.fillStyle = o.color ?? INK;
    ctx.textAlign = o.align ?? 'right';
    ctx.textBaseline = 'middle';
    ctx.fillText(t, x, yy);
  };

  const finishPage = () => {
    if (!canvas) return;
    ctx.strokeStyle = GOLD;
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(M, H - FOOT);
    ctx.lineTo(W - M, H - FOOT);
    ctx.stroke();
    text(spec.hotelName, W - M, H - FOOT + 38, { size: 22, color: MUTED });
    text(`صفحة ${pageNo}`, W / 2, H - FOOT + 38, { size: 22, color: MUTED, align: 'center' });
    text(`تاريخ الطباعة: ${printedAt}`, M, H - FOOT + 38, { size: 22, color: MUTED, align: 'left' });
    pageImages.push(canvas.toDataURL('image/jpeg', 0.9));
    canvas.width = 1; // release memory
    canvas.height = 1;
  };

  const startPage = () => {
    finishPage();
    pageNo += 1;
    canvas = document.createElement('canvas');
    canvas.width = W;
    canvas.height = H;
    ctx = canvas.getContext('2d') as Ctx;
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, W, H);
    try {
      (ctx as any).direction = 'rtl';
    } catch {
      /* old WebView */
    }
    if (pageNo === 1) {
      ctx.fillStyle = NAVY;
      ctx.fillRect(0, 0, W, 190);
      ctx.fillStyle = GOLD;
      ctx.fillRect(0, 190, W, 6);
      text(spec.hotelName, W / 2, 82, { size: 54, bold: true, color: GOLD, align: 'center' });
      if (spec.hotelAddress) text(spec.hotelAddress, W / 2, 142, { size: 26, color: '#e8dfc0', align: 'center' });
      text(spec.title, W / 2, 262, { size: 42, bold: true, color: NAVY, align: 'center' });
      ctx.fillStyle = GOLD;
      ctx.fillRect(W / 2 - 80, 296, 160, 4);
      y = 330;
    } else {
      ctx.fillStyle = NAVY;
      ctx.fillRect(0, 0, W, 80);
      text(`${spec.hotelName} — ${spec.title}`, W / 2, 42, { size: 28, bold: true, color: GOLD, align: 'center' });
      y = 120;
    }
  };

  const ensure = (h: number) => {
    if (y + h > H - FOOT - 20) {
      startPage();
      return true;
    }
    return false;
  };

  startPage();

  // ---- meta panel ----
  const metaR = spec.metaRight ?? [];
  const metaL = spec.metaLeft ?? [];
  if (metaR.length || metaL.length) {
    const colW = (W - 2 * M) / 2 - 40;
    ctx.font = font(26);
    const mk = (arr: [string, string][]) => arr.map(([l, v]) => wrap(ctx, `${l}: ${v}`, colW, 2));
    const rLines = mk(metaR);
    const lLines = mk(metaL);
    const hOf = (ls: string[][]) => ls.reduce((a, l) => a + l.length * 38 + 6, 0);
    const panelH = Math.max(hOf(rLines), hOf(lLines)) + 40;
    ensure(panelH + 20);
    ctx.fillStyle = PAPER;
    ctx.fillRect(M, y, W - 2 * M, panelH);
    ctx.strokeStyle = GRID;
    ctx.lineWidth = 2;
    ctx.strokeRect(M, y, W - 2 * M, panelH);
    const draw = (ls: string[][], rightX: number) => {
      let yy = y + 36;
      ls.forEach((lines) => {
        lines.forEach((ln) => {
          text(ln, rightX, yy, { size: 26 });
          yy += 38;
        });
        yy += 6;
      });
    };
    draw(rLines, W - M - 24);
    draw(lLines, W / 2 - 10);
    y += panelH + 30;
  }

  // ---- table ----
  if (spec.columns && spec.columns.length) {
    const cols = spec.columns;
    const total = cols.reduce((a, c) => a + c.width, 0);
    const usable = W - 2 * M;
    const widths = cols.map((c) => (c.width / total) * usable);
    const rights: number[] = [];
    let acc = W - M;
    widths.forEach((w) => {
      rights.push(acc);
      acc -= w;
    });

    const drawHeader = () => {
      ensure(64 + 70);
      ctx.fillStyle = NAVY;
      ctx.fillRect(M, y, usable, 64);
      cols.forEach((c, i) => {
        text(c.header, rights[i] - widths[i] / 2, y + 33, { size: 25, bold: true, color: GOLD, align: 'center' });
      });
      y += 64;
    };
    drawHeader();

    const rows = spec.rows ?? [];
    if (!rows.length) {
      ensure(80);
      ctx.fillStyle = PAPER;
      ctx.fillRect(M, y, usable, 80);
      text('لا توجد بيانات', W / 2, y + 40, { size: 26, color: MUTED, align: 'center' });
      y += 80;
    }

    rows.forEach((row, ri) => {
      ctx.font = font(24);
      const prepared = cols.map((c, i) => {
        const cell = row[i];
        if (isImage(cell)) return { img: cell as CanvasImageSource, lines: [] as string[] };
        return { img: null as CanvasImageSource | null, lines: wrap(ctx, String(cell ?? '—'), widths[i] - 24, 3) };
      });
      const hasImg = prepared.some((p) => p.img);
      const rowH = Math.max(
        hasImg ? 120 : 56,
        ...prepared.map((p) => (p.lines.length ? p.lines.length * 34 + 22 : 0))
      );
      if (ensure(rowH)) drawHeader();

      ctx.fillStyle = ri % 2 === 0 ? '#ffffff' : PAPER;
      ctx.fillRect(M, y, usable, rowH);
      ctx.strokeStyle = GRID;
      ctx.lineWidth = 1;
      ctx.strokeRect(M, y, usable, rowH);

      prepared.forEach((p, i) => {
        const left = rights[i] - widths[i];
        if (p.img) {
          const box = Math.min(rowH - 16, widths[i] - 16);
          const iw = (p.img as any).width || box;
          const ih = (p.img as any).height || box;
          const sc = Math.min(box / iw, box / ih);
          const dw = iw * sc;
          const dh = ih * sc;
          try {
            ctx.drawImage(p.img, left + (widths[i] - dw) / 2, y + (rowH - dh) / 2, dw, dh);
          } catch {
            /* ignore broken image */
          }
        } else {
          const align = cols[i].align ?? 'right';
          const tx = align === 'right' ? rights[i] - 12 : align === 'left' ? left + 12 : left + widths[i] / 2;
          const startY = y + rowH / 2 - ((p.lines.length - 1) * 34) / 2;
          ctx.save();
          ctx.beginPath();
          ctx.rect(left, y, widths[i], rowH);
          ctx.clip();
          p.lines.forEach((ln, li) => text(ln, tx, startY + li * 34, { size: 24, align }));
          ctx.restore();
        }
      });
      y += rowH;
    });
    y += 30;
  }

  // ---- totals ----
  if (spec.totals && spec.totals.length) {
    const rowH = 56;
    const boxW = 600;
    ensure(spec.totals.length * rowH + 20);
    spec.totals.forEach(([label, value], i) => {
      const last = i === spec.totals!.length - 1;
      const top = y + i * rowH;
      ctx.fillStyle = last ? GOLD : i % 2 === 0 ? PAPER : '#ffffff';
      ctx.fillRect(M, top, boxW, rowH);
      ctx.strokeStyle = GRID;
      ctx.strokeRect(M, top, boxW, rowH);
      text(label, M + boxW - 16, top + rowH / 2, { size: 26, bold: last, color: last ? NAVY : INK });
      text(value, M + 16, top + rowH / 2, { size: 26, bold: true, color: last ? NAVY : INK, align: 'left' });
    });
    y += spec.totals.length * rowH + 30;
  }

  // ---- note ----
  if (spec.note) {
    ctx.font = font(24);
    const lines = wrap(ctx, spec.note, W - 2 * M, 6);
    ensure(lines.length * 34 + 20);
    lines.forEach((ln) => {
      text(ln, W - M, y + 17, { size: 24, color: MUTED });
      y += 34;
    });
    y += 20;
  }

  // ---- signatures ----
  if (spec.signatures && spec.signatures.length) {
    ensure(150);
    y += 70;
    const n = spec.signatures.length;
    const slot = (W - 2 * M) / n;
    spec.signatures.forEach((label, i) => {
      const cx = W - M - slot * i - slot / 2;
      ctx.strokeStyle = INK;
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(cx - 140, y);
      ctx.lineTo(cx + 140, y);
      ctx.stroke();
      text(label, cx, y + 34, { size: 24, color: MUTED, align: 'center' });
    });
    y += 70;
  }

  finishPage();

  const pdf = new jsPDF({ orientation: landscape ? 'l' : 'p', unit: 'mm', format: 'a4', compress: true });
  const pw = landscape ? 297 : 210;
  const ph = landscape ? 210 : 297;
  pageImages.forEach((img, i) => {
    if (i > 0) pdf.addPage('a4', landscape ? 'l' : 'p');
    pdf.addImage(img, 'JPEG', 0, 0, pw, ph, undefined, 'FAST');
  });
  return pdf.output('blob');
}

const safeName = (s: string) => s.replace(/[\\/:*?"<>|\s]+/g, '_');

export async function exportArabicPdf(spec: PdfSpec, filename: string): Promise<void> {
  try {
    const blob = await buildArabicPdf(spec);
    await saveBlob(`${safeName(filename)}.pdf`.replace(/\.pdf\.pdf$/, '.pdf'), blob);
  } catch (err) {
    console.error('PDF export failed', err);
    alert('تعذّر إنشاء ملف PDF.');
  }
}

export const money = (n: number | undefined | null, symbol = ''): string =>
  `${Number(n ?? 0).toLocaleString('en-US')}${symbol ? ` ${symbol}` : ''}`;

export const paymentMethodAr = (m?: string): string =>
  m === 'card' ? 'بطاقة بنكية' : m === 'cash' ? 'نقداً' : m === 'transfer' ? 'تحويل بنكي' : m === 'unpaid' ? 'آجل / لم يُدفع' : m || '—';

/** Load an image (data URL) so it can be placed in a PDF table cell. */
export const loadImg = (src: string): Promise<HTMLImageElement | null> =>
  new Promise((resolve) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () => resolve(null);
    img.src = src;
  });
