import React, { useState } from 'react';
import { useHotel } from '../context/HotelContext';
import { ActivityLog } from '../types/hotel';
import {
  FileText,
  Clock,
  Filter,
  CheckCircle,
  Database,
  Building,
  User,
  CreditCard,
  Sparkles,
} from 'lucide-react';

export const LogsView: React.FC = () => {
  const { logs } = useHotel();
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  const filteredLogs = logs.filter((log) => {
    if (selectedCategory !== 'all' && log.category !== selectedCategory) return false;
    return true;
  });

  const getCategoryBadge = (cat: ActivityLog['category']) => {
    switch (cat) {
      case 'booking':
        return { label: 'حجز وتسجيل', bg: 'bg-emerald-500/20 text-emerald-600 dark:text-emerald-400' };
      case 'room':
        return { label: 'غرفة', bg: 'bg-blue-500/20 text-blue-600 dark:text-blue-400' };
      case 'guest':
        return { label: 'نزيل', bg: 'bg-indigo-500/20 text-indigo-600 dark:text-indigo-400' };
      case 'housekeeping':
        return { label: 'هاوس كيبينج', bg: 'bg-amber-500/20 text-amber-600 dark:text-amber-400' };
      case 'payment':
        return { label: 'مدفوعات', bg: 'bg-purple-500/20 text-purple-600 dark:text-purple-400' };
      case 'database':
        return { label: 'قاعدة بيانات', bg: 'bg-slate-500/20 text-slate-600 dark:text-slate-400' };
    }
  };

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <Clock className="w-5 h-5 text-indigo-600" />
            سجل العمليات والنشاطات (System Activity Logs)
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            سجل تدقيق فوري لكافة عمليات التسكين، المغادرة، الهاوس كيبينج وتعديلات SQLite
          </p>
        </div>

        {/* Category Filter */}
        <select
          value={selectedCategory}
          onChange={(e) => setSelectedCategory(e.target.value)}
          className="bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs rounded-lg px-2.5 py-1.5 text-slate-700 dark:text-slate-300 focus:outline-none"
        >
          <option value="all">كل الفئات ({logs.length})</option>
          <option value="booking">حجوزات</option>
          <option value="housekeeping">هاوس كيبينج</option>
          <option value="guest">نزلاء</option>
          <option value="payment">سندات قبض</option>
          <option value="database">قاعدة البيانات</option>
        </select>
      </div>

      {/* Logs Timeline */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm divide-y divide-slate-100 dark:divide-slate-800">
        {filteredLogs.length === 0 ? (
          <div className="p-8 text-center text-slate-400 text-xs">لا توجد سجلات مطابقة</div>
        ) : (
          filteredLogs.map((log) => {
            const badge = getCategoryBadge(log.category);
            return (
              <div key={log.id} className="p-4 flex items-start justify-between gap-4 hover:bg-slate-50/50 dark:hover:bg-slate-800/30 transition text-xs">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${badge.bg}`}>
                      {badge.label}
                    </span>
                    <strong className="text-slate-900 dark:text-white font-semibold">{log.action}</strong>
                  </div>
                  <p className="text-slate-600 dark:text-slate-400">{log.details}</p>
                </div>

                <div className="text-slate-400 text-[11px] font-mono shrink-0">
                  {log.timestamp}
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
