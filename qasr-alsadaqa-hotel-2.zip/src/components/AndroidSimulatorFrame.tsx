import { isNativeApp } from '../utils/saveFile';
import React from 'react';
import { useHotel } from '../context/HotelContext';
import {
  Wifi,
  Battery,
  Signal,
  Home,
  Calendar,
  UtensilsCrossed,
  ArrowLeftRight,
  BarChart3,
  Smartphone,
  Plus,
} from 'lucide-react';

interface AndroidSimulatorFrameProps {
  children: React.ReactNode;
}

export const AndroidSimulatorFrame: React.FC<AndroidSimulatorFrameProps> = ({ children }) => {
  const {
    isAndroidView,
    setIsAndroidView,
    activeTab,
    setActiveTab,
    setIsCheckInModalOpen,
    roomServiceOrders,
  } = useHotel();

  if (!isAndroidView || isNativeApp()) {
    return <>{children}</>;
  }

  const activeOrdersCount = roomServiceOrders.filter(
    (o) => o.status === 'pending' || o.status === 'preparing' || o.status === 'on_the_way'
  ).length;

  return (
    <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center p-2 sm:p-6 text-white animate-fadeIn" dir="rtl">
      {/* Top Banner with Toggle Back */}
      <div className="w-full max-w-md mb-3 flex items-center justify-between px-2 text-xs">
        <div className="flex items-center gap-2">
          <Smartphone className="w-4 h-4 text-sky-400" />
          <span className="font-bold text-slate-200">معاينة شاشة تطبيق أندرويد</span>
        </div>
        <button
          onClick={() => setIsAndroidView(false)}
          className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg border border-slate-700 transition cursor-pointer text-xs"
        >
          خروج للوضع المكتبي ✕
        </button>
      </div>

      {/* Android Device Shell */}
      <div className="w-full max-w-md bg-black rounded-[42px] p-3 shadow-2xl ring-1 ring-slate-800 border-4 border-slate-800 relative flex flex-col h-[840px] max-h-[92vh] overflow-hidden">
        {/* Android Top Speaker & Camera Notch */}
        <div className="absolute top-4 left-1/2 -translate-x-1/2 z-40 flex items-center gap-2">
          <div className="w-16 h-4 bg-black rounded-full flex items-center justify-center">
            <div className="w-3 h-3 rounded-full bg-slate-900 ring-1 ring-slate-800" />
          </div>
        </div>

        {/* Android Status Bar */}
        <div className="pt-2 px-5 pb-1 flex items-center justify-between text-[11px] font-mono text-slate-400 z-30 shrink-0 select-none">
          <span className="font-semibold text-white">12:30</span>
          <div className="flex items-center gap-1.5">
            <Signal className="w-3 h-3 text-slate-300" />
            <Wifi className="w-3.5 h-3.5 text-slate-300" />
            <Battery className="w-4 h-4 text-slate-300" />
          </div>
        </div>

        {/* Main Content inside Android Viewport */}
        <div className="flex-1 overflow-y-auto rounded-3xl bg-slate-900 text-slate-100 flex flex-col relative no-scrollbar">
          {children}
        </div>

        {/* Android Bottom Navigation Bar (Material 3 style) */}
        <div className="bg-slate-950 border-t border-slate-800/80 px-2 py-2 flex items-center justify-around text-xs shrink-0 select-none z-30">
          <button
            onClick={() => setActiveTab('rooms')}
            className={`flex flex-col items-center gap-1 p-1 rounded-xl transition cursor-pointer ${
              activeTab === 'rooms' ? 'text-sky-400 font-bold' : 'text-slate-500 hover:text-slate-300'
            }`}
          >
            <Home className="w-4 h-4" />
            <span className="text-[10px]">الرئيسية</span>
          </button>

          <button
            onClick={() => setActiveTab('reservations')}
            className={`flex flex-col items-center gap-1 p-1 rounded-xl transition cursor-pointer ${
              activeTab === 'reservations' ? 'text-sky-400 font-bold' : 'text-slate-500 hover:text-slate-300'
            }`}
          >
            <Calendar className="w-4 h-4" />
            <span className="text-[10px]">الحجز</span>
          </button>

          <button
            onClick={() => setActiveTab('room_service')}
            className={`flex flex-col items-center gap-1 p-1 rounded-xl transition cursor-pointer relative ${
              activeTab === 'room_service' ? 'text-sky-400 font-bold' : 'text-slate-500 hover:text-slate-300'
            }`}
          >
            <UtensilsCrossed className="w-4 h-4" />
            <span className="text-[10px]">خدمة الغرف</span>
            {activeOrdersCount > 0 && (
              <span className="absolute top-0 right-1 w-2 h-2 rounded-full bg-amber-500 animate-ping"></span>
            )}
          </button>

          <button
            onClick={() => setActiveTab('finance')}
            className={`flex flex-col items-center gap-1 p-1 rounded-xl transition cursor-pointer ${
              activeTab === 'finance' ? 'text-sky-400 font-bold' : 'text-slate-500 hover:text-slate-300'
            }`}
          >
            <ArrowLeftRight className="w-4 h-4" />
            <span className="text-[10px]">الرواتب والمصروفات</span>
          </button>

          <button
            onClick={() => setActiveTab('reports')}
            className={`flex flex-col items-center gap-1 p-1 rounded-xl transition cursor-pointer ${
              activeTab === 'reports' ? 'text-sky-400 font-bold' : 'text-slate-500 hover:text-slate-300'
            }`}
          >
            <BarChart3 className="w-4 h-4" />
            <span className="text-[10px]">الإحصائيات</span>
          </button>
        </div>

        {/* Android Home Navigation Bar Pill */}
        <div className="pt-1 pb-1.5 flex justify-center shrink-0">
          <div className="w-28 h-1 bg-slate-600 rounded-full"></div>
        </div>
      </div>
    </div>
  );
};
