import React, { useState } from 'react';
import { useHotel } from '../context/HotelContext';
import {
  DollarSign,
  TrendingUp,
  CreditCard,
  Building,
  Download,
  Calendar,
  Users,
  CheckCircle,
  FileSpreadsheet,
  Layers,
  Sparkles,
  UtensilsCrossed,
} from 'lucide-react';

export const ReportsView: React.FC = () => {
  const {
    rooms,
    guests,
    bookings,
    payments,
    settings,
    roomServiceOrders,
    exportRoomsCsv,
    exportGuestsCsv,
  } = useHotel();

  const [dateRange, setDateRange] = useState<'today' | 'month' | 'all'>('month');

  // Metrics calculation
  const totalRevenue = payments.reduce((sum, p) => sum + p.amount, 0);
  const cardRevenue = payments.filter((p) => p.method === 'card').reduce((sum, p) => sum + p.amount, 0);
  const cashRevenue = payments.filter((p) => p.method === 'cash').reduce((sum, p) => sum + p.amount, 0);
  const transferRevenue = payments.filter((p) => p.method === 'transfer').reduce((sum, p) => sum + p.amount, 0);

  const roomServiceRevenue = roomServiceOrders
    .filter((o) => o.status !== 'cancelled' && o.chargeTo !== 'complimentary')
    .reduce((sum, o) => sum + o.totalAmount, 0);

  const occupiedRoomsCount = rooms.filter((r) => r.status === 'occupied').length;
  const occupancyRate = Math.round((occupiedRoomsCount / rooms.length) * 100);

  // Average Daily Rate (ADR)
  const activeBookings = bookings.filter((b) => b.isActive);
  const avgRate =
    activeBookings.length > 0
      ? Math.round(activeBookings.reduce((sum, b) => sum + b.pricePerNight, 0) / activeBookings.length)
      : 0;

  // RevPAR (Revenue Per Available Room)
  const revPar = Math.round((avgRate * occupancyRate) / 100);

  // Frequent guests ratio
  const frequentGuestsCount = guests.filter((g) => g.isFrequent).length;
  const loyaltyRatio = Math.round((frequentGuestsCount / guests.length) * 100);

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-emerald-600" />
            التقارير المالية ومؤشرات الأداء الفندقي (PMS Analytics)
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            ملخص الإيرادات، إقفال الصندوق، وتوزيع الإشغال المحسوب محلياً
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={exportRoomsCsv}
            className="px-3 py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition cursor-pointer border border-slate-200 dark:border-slate-700"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600" />
            <span>تصدير الغرف (CSV)</span>
          </button>
          <button
            onClick={exportGuestsCsv}
            className="px-3 py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition cursor-pointer border border-slate-200 dark:border-slate-700"
          >
            <Download className="w-3.5 h-3.5 text-indigo-600" />
            <span>تصدير النزلاء (CSV)</span>
          </button>
        </div>
      </div>

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Revenue */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-sm space-y-1">
          <div className="flex items-center justify-between text-xs text-slate-500">
            <span>إجمالي الإيرادات المحصلة</span>
            <div className="w-8 h-8 rounded-xl bg-emerald-500/10 text-emerald-600 flex items-center justify-center">
              <DollarSign className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-black text-slate-900 dark:text-white font-mono">
            {totalRevenue.toLocaleString()} {settings.currencySymbol}
          </div>
          <div className="text-[11px] text-emerald-600 font-medium">
            مستندة على {payments.length} سند قبض في SQLite
          </div>
        </div>

        {/* Occupancy Rate */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-sm space-y-1">
          <div className="flex items-center justify-between text-xs text-slate-500">
            <span>نسبة الإشغال الحالية</span>
            <div className="w-8 h-8 rounded-xl bg-rose-500/10 text-rose-600 flex items-center justify-center">
              <Building className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-black text-slate-900 dark:text-white font-mono">
            {occupancyRate}%
          </div>
          <div className="text-[11px] text-slate-500">
            {occupiedRoomsCount} مشغولة من إجمالي {rooms.length} غرفة
          </div>
        </div>

        {/* ADR (Average Daily Rate) */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-sm space-y-1">
          <div className="flex items-center justify-between text-xs text-slate-500">
            <span>متوسط سعر الليلة (ADR)</span>
            <div className="w-8 h-8 rounded-xl bg-indigo-500/10 text-indigo-600 flex items-center justify-center">
              <TrendingUp className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-black text-slate-900 dark:text-white font-mono">
            {avgRate} {settings.currencySymbol}
          </div>
          <div className="text-[11px] text-indigo-600 font-medium">
            RevPAR: {revPar} {settings.currencySymbol}
          </div>
        </div>

        {/* Loyalty Members Ratio */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-sm space-y-1">
          <div className="flex items-center justify-between text-xs text-slate-500">
            <span>نسبة العملاء المستمرين (Loyalty)</span>
            <div className="w-8 h-8 rounded-xl bg-amber-500/10 text-amber-600 flex items-center justify-center">
              <Sparkles className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-black text-slate-900 dark:text-white font-mono">
            {loyaltyRatio}%
          </div>
          <div className="text-[11px] text-amber-600 font-medium">
            {frequentGuestsCount} عميل دائم من أصل {guests.length} مسجل
          </div>
        </div>
      </div>

      {/* Payment Methods Breakdown & Shift Close */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Payment Methods Card */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-sm space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
            <h3 className="font-bold text-slate-900 dark:text-white text-sm flex items-center gap-2">
              <CreditCard className="w-4 h-4 text-emerald-600" />
              توزيع الإيرادات حسب وسيلة الدفع
            </h3>
            <span className="text-xs text-slate-400 font-mono">
              الإجمالي: {totalRevenue} {settings.currencySymbol}
            </span>
          </div>

          <div className="space-y-3 text-xs">
            {/* Card */}
            <div className="space-y-1">
              <div className="flex items-center justify-between">
                <span className="font-semibold text-slate-700 dark:text-slate-300">
                  💳 بطاقات مدى وفيزا (Cards)
                </span>
                <span className="font-bold font-mono">
                  {cardRevenue} {settings.currencySymbol} ({Math.round((cardRevenue / totalRevenue) * 100 || 0)}%)
                </span>
              </div>
              <div className="w-full bg-slate-100 dark:bg-slate-800 h-2 rounded-full overflow-hidden">
                <div
                  className="bg-emerald-500 h-full"
                  style={{ width: `${(cardRevenue / totalRevenue) * 100 || 0}%` }}
                />
              </div>
            </div>

            {/* Cash */}
            <div className="space-y-1">
              <div className="flex items-center justify-between">
                <span className="font-semibold text-slate-700 dark:text-slate-300">
                  💵 نقداً (Cash in Hand)
                </span>
                <span className="font-bold font-mono">
                  {cashRevenue} {settings.currencySymbol} ({Math.round((cashRevenue / totalRevenue) * 100 || 0)}%)
                </span>
              </div>
              <div className="w-full bg-slate-100 dark:bg-slate-800 h-2 rounded-full overflow-hidden">
                <div
                  className="bg-amber-500 h-full"
                  style={{ width: `${(cashRevenue / totalRevenue) * 100 || 0}%` }}
                />
              </div>
            </div>

            {/* Transfer */}
            <div className="space-y-1">
              <div className="flex items-center justify-between">
                <span className="font-semibold text-slate-700 dark:text-slate-300">
                  🏦 تحويلات بنكية (Bank Transfer)
                </span>
                <span className="font-bold font-mono">
                  {transferRevenue} {settings.currencySymbol} (
                  {Math.round((transferRevenue / totalRevenue) * 100 || 0)}%)
                </span>
              </div>
              <div className="w-full bg-slate-100 dark:bg-slate-800 h-2 rounded-full overflow-hidden">
                <div
                  className="bg-indigo-500 h-full"
                  style={{ width: `${(transferRevenue / totalRevenue) * 100 || 0}%` }}
                />
              </div>
            </div>
          </div>
        </div>

        {/* Daily Cashier Reconciliation / Shift Close */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-sm space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
            <h3 className="font-bold text-slate-900 dark:text-white text-sm flex items-center gap-2">
              <CheckCircle className="w-4 h-4 text-emerald-600" />
              إقفال وردية الصندوق اليومي (Cashier Shift Reconciliation)
            </h3>
            <span className="text-[11px] px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 font-semibold">
              الوردية متوازنة
            </span>
          </div>

          <div className="grid grid-cols-2 gap-3 text-xs">
            <div className="p-3 bg-slate-50 dark:bg-slate-800/40 rounded-xl border border-slate-100 dark:border-slate-800">
              <span className="text-slate-400 block text-[11px]">مقبوضات الكاش بالدرج:</span>
              <strong className="text-base font-mono text-slate-900 dark:text-white">
                {cashRevenue} {settings.currencySymbol}
              </strong>
            </div>

            <div className="p-3 bg-slate-50 dark:bg-slate-800/40 rounded-xl border border-slate-100 dark:border-slate-800">
              <span className="text-slate-400 block text-[11px]">مقبوضات نقاط البيع (POS):</span>
              <strong className="text-base font-mono text-slate-900 dark:text-white">
                {cardRevenue} {settings.currencySymbol}
              </strong>
            </div>

            <div className="p-3 bg-slate-50 dark:bg-slate-800/40 rounded-xl border border-slate-100 dark:border-slate-800">
              <span className="text-slate-400 block text-[11px]">عدد الحجوزات النشطة:</span>
              <strong className="text-base font-mono text-slate-900 dark:text-white">
                {bookings.filter((b) => b.isActive).length} حجز
              </strong>
            </div>

            <div className="p-3 bg-slate-50 dark:bg-slate-800/40 rounded-xl border border-slate-100 dark:border-slate-800">
              <span className="text-slate-400 block text-[11px]">مبيعات خدمة الغرف (KOT):</span>
              <strong className="text-base font-mono text-amber-500">
                {roomServiceRevenue.toLocaleString()} {settings.currencySymbol}
              </strong>
            </div>

            <div className="p-3 bg-slate-50 dark:bg-slate-800/40 rounded-xl border border-slate-100 dark:border-slate-800">
              <span className="text-slate-400 block text-[11px]">حالة قاعدة بيانات SQLite:</span>
              <strong className="text-xs text-emerald-600 dark:text-emerald-400 flex items-center gap-1 mt-1">
                <CheckCircle className="w-3.5 h-3.5" />
                متصلة ومحفوظة محلياً
              </strong>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
