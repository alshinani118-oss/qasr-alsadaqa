import React, { useState } from 'react';
import { useHotel } from '../context/HotelContext';
import { Room, RoomStatus, PaymentMethod } from '../types/hotel';
import {
  X,
  User,
  Phone,
  CreditCard,
  Calendar,
  Clock,
  Sparkles,
  Plus,
  FileText,
  LogOut,
  CheckCircle2,
  AlertTriangle,
  Receipt,
  Bed,
  Shield,
  Layers,
  Wrench,
  Trash2,
  ArrowLeftRight,
} from 'lucide-react';

export const RoomDetailModal: React.FC = () => {
  const {
    selectedRoom,
    setSelectedRoom,
    bookings,
    guests,
    settings,
    checkOut,
    completeHousekeeping,
    updateRoomStatus,
    addAdditionalCharge,
    extendBookingNights,
    deleteRoom,
    setIsCheckInModalOpen,
    generatePdfInvoice,
    setSelectedGuestForStatement,
    setIsLinkGuestModalOpen,
    setPreselectedRoomForLink,
    setIsNewRoomServiceModalOpen,
    setPreselectedRoomForRoomService,
  } = useHotel();

  // Dialog sub-states
  const [isAddingCharge, setIsAddingCharge] = useState<boolean>(false);
  const [chargeDesc, setChargeDesc] = useState<string>('');
  const [chargeAmount, setChargeAmount] = useState<string>('');

  const [isExtending, setIsExtending] = useState<boolean>(false);
  const [extraNights, setExtraNights] = useState<number>(1);

  const [isCheckOutConfirm, setIsCheckOutConfirm] = useState<boolean>(false);
  const [settleMethod, setSettleMethod] = useState<PaymentMethod>('card');

  const [isDeleteConfirm, setIsDeleteConfirm] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string>('');

  if (!selectedRoom) return null;

  const activeBooking = bookings.find((b) => b.id === selectedRoom.currentBookingId && b.isActive);
  const currentGuest = activeBooking
    ? guests.find((g) => g.id === activeBooking.guestId)
    : selectedRoom.currentGuestPhone
    ? guests.find((g) => g.phone === selectedRoom.currentGuestPhone)
    : undefined;

  const unpaidBalance = activeBooking ? activeBooking.totalAmount - activeBooking.paidAmount : 0;

  const handleAddChargeSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeBooking || !chargeDesc || !chargeAmount) return;
    addAdditionalCharge(activeBooking.id, chargeDesc, parseFloat(chargeAmount));
    setChargeDesc('');
    setChargeAmount('');
    setIsAddingCharge(false);
  };

  const handleExtendSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeBooking || extraNights <= 0) return;
    extendBookingNights(activeBooking.id, extraNights);
    setIsExtending(false);
  };

  const handleConfirmCheckOut = async () => {
    if (unpaidBalance > 0) {
      await checkOut(selectedRoom.id, unpaidBalance, settleMethod);
    } else {
      await checkOut(selectedRoom.id, 0);
    }
    setIsCheckOutConfirm(false);
    setSelectedRoom(null);
  };

  const handleDeleteRoom = () => {
    setErrorMessage('');
    const res = deleteRoom(selectedRoom.id);
    if (res.success) {
      setSelectedRoom(null);
    } else {
      setErrorMessage(res.error || 'تعذر حذف الغرفة.');
    }
  };

  const handleOpenGuestStatement = () => {
    if (currentGuest) {
      setSelectedGuestForStatement(currentGuest);
    }
  };

  const handleOpenLinkModal = () => {
    setPreselectedRoomForLink(selectedRoom);
    setSelectedRoom(null);
    setIsLinkGuestModalOpen(true);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/75 backdrop-blur-xs animate-fadeIn">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto shadow-2xl flex flex-col">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between bg-slate-50 dark:bg-slate-950/50 sticky top-0 z-10">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-slate-900 dark:bg-slate-800 text-white flex flex-col items-center justify-center font-bold shadow-xs">
              <span className="text-xs text-slate-400 font-normal">غرفة</span>
              <span className="text-base leading-none text-emerald-400 font-mono">#{selectedRoom.roomNumber}</span>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-bold text-slate-900 dark:text-white">
                  تفاصيل الغرفة {selectedRoom.roomNumber}
                </h2>
                <span className="text-xs text-slate-500 font-mono">الطابق {selectedRoom.floor}</span>
              </div>
              <p className="text-xs text-slate-500">
                السعر الأساسي: {selectedRoom.pricePerNight} {settings.currencySymbol} / ليلة • السعة:{' '}
                {selectedRoom.capacity} أفراد • {selectedRoom.type}
              </p>
            </div>
          </div>

          <button
            onClick={() => setSelectedRoom(null)}
            className="p-2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-5 space-y-4">
          {errorMessage && (
            <div className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900 text-xs text-rose-700 dark:text-rose-300 flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 shrink-0 text-rose-500" />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* Status Alert Banner */}
          <div className="flex items-center justify-between p-3 rounded-xl bg-slate-100 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/60 text-xs">
            <div className="flex items-center gap-2">
              <span className="font-semibold text-slate-700 dark:text-slate-300">حالة الغرفة الحالية:</span>
              <span
                className={`px-2.5 py-0.5 rounded-full font-bold text-xs ${
                  selectedRoom.status === 'available'
                    ? 'bg-emerald-500/20 text-emerald-600 dark:text-emerald-400'
                    : selectedRoom.status === 'occupied'
                    ? 'bg-rose-500/20 text-rose-600 dark:text-rose-400'
                    : selectedRoom.status === 'cleaning'
                    ? 'bg-amber-500/20 text-amber-600 dark:text-amber-400'
                    : 'bg-purple-500/20 text-purple-600 dark:text-purple-400'
                }`}
              >
                {selectedRoom.status === 'available'
                  ? '🟢 متاحة وجاهزة'
                  : selectedRoom.status === 'occupied'
                  ? '🔴 مشغولة بحجز نشط'
                  : selectedRoom.status === 'cleaning'
                  ? '🟡 تحت التنظيف والتعقيم'
                  : '🟣 صيانة وتجهيز'}
              </span>
            </div>

            {/* Quick Status Override selector */}
            <div className="flex items-center gap-1">
              <label className="text-slate-400 text-[11px]">تغيير يدوي:</label>
              <select
                value={selectedRoom.status}
                onChange={(e) => updateRoomStatus(selectedRoom.id, e.target.value as RoomStatus)}
                className="bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-[11px] rounded px-2 py-1 text-slate-700 dark:text-slate-300 focus:outline-none"
              >
                <option value="available">متاحة</option>
                <option value="occupied">مشغولة</option>
                <option value="cleaning">تنظيف</option>
                <option value="maintenance">صيانة</option>
              </select>
            </div>
          </div>

          {/* Occupied View Details */}
          {selectedRoom.status === 'occupied' && activeBooking && (
            <div className="space-y-4">
              {/* Guest Profile Box */}
              <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-700/50 space-y-3">
                <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-700/60 pb-2">
                  <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">بيانات النزيل والحجز</span>
                  <span className="text-xs font-mono font-bold text-emerald-600 dark:text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded">
                    كود الحجز: {activeBooking.bookingCode}
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                  <div className="flex items-center gap-2">
                    <User className="w-4 h-4 text-slate-400 shrink-0" />
                    <div>
                      <span className="text-slate-400 block text-[11px]">اسم العميل:</span>
                      <strong className="text-slate-800 dark:text-slate-200">{activeBooking.guestName}</strong>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <Phone className="w-4 h-4 text-slate-400 shrink-0" />
                    <div>
                      <span className="text-slate-400 block text-[11px]">رقم الهاتف:</span>
                      <a
                        href={`tel:${activeBooking.guestPhone}`}
                        className="text-emerald-600 dark:text-emerald-400 font-mono hover:underline"
                      >
                        {activeBooking.guestPhone}
                      </a>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <Calendar className="w-4 h-4 text-slate-400 shrink-0" />
                    <div>
                      <span className="text-slate-400 block text-[11px]">فترة الإقامة:</span>
                      <span className="font-mono text-slate-700 dark:text-slate-300">
                        {activeBooking.checkInDate.substring(0, 10)} ⬅ {activeBooking.expectedCheckOutDate.substring(0, 10)} ({activeBooking.nights} ليالي)
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <CreditCard className="w-4 h-4 text-slate-400 shrink-0" />
                    <div>
                      <span className="text-slate-400 block text-[11px]">طريقة الدفع:</span>
                      <span className="text-slate-700 dark:text-slate-300">
                        {activeBooking.paymentMethod === 'card'
                          ? 'بطاقة بنكية / مدى'
                          : activeBooking.paymentMethod === 'cash'
                          ? 'نقداً كاش'
                          : 'تحويل بنكي'}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Frequent Tenant Badge / Statement Link */}
                <div className="pt-2 border-t border-slate-200 dark:border-slate-700/60 flex items-center justify-between">
                  {currentGuest?.isFrequent ? (
                    <span className="text-xs text-amber-600 dark:text-amber-400 font-bold flex items-center gap-1">
                      <Sparkles className="w-3.5 h-3.5" />
                      مستأجر دائم ({currentGuest.visitCount} إقامات - خصم {currentGuest.loyaltyDiscountPercent}%)
                    </span>
                  ) : (
                    <span className="text-xs text-slate-400">نزيل معتمد في النظام</span>
                  )}

                  {currentGuest && (
                    <button
                      type="button"
                      onClick={handleOpenGuestStatement}
                      className="px-3 py-1.5 bg-slate-900 dark:bg-slate-700 hover:bg-slate-800 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 transition cursor-pointer shadow-xs"
                    >
                      <FileText className="w-3.5 h-3.5 text-emerald-400" />
                      <span>كشف حساب النزيل الكامل</span>
                    </button>
                  )}
                </div>
              </div>

              {/* Financial Calculation Box */}
              <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-700/50 space-y-3">
                <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-700/60 pb-2">
                  <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">الحساب والخدمات الإضافية</span>
                  <div className="flex items-center gap-2 flex-wrap">
                    <button
                      type="button"
                      onClick={() => {
                        setPreselectedRoomForRoomService(selectedRoom);
                        setIsNewRoomServiceModalOpen(true);
                      }}
                      className="px-2.5 py-1 bg-amber-500 hover:bg-amber-400 text-slate-950 rounded-lg text-xs font-bold flex items-center gap-1 transition cursor-pointer shadow-sm"
                    >
                      <Plus className="w-3 h-3" />
                      <span>🍽️ طلب خدمة غرف</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setIsAddingCharge(!isAddingCharge)}
                      className="text-xs text-emerald-600 hover:underline font-bold flex items-center gap-1 cursor-pointer"
                    >
                      <Plus className="w-3.5 h-3.5" /> + رسوم يدوية
                    </button>
                    <button
                      type="button"
                      onClick={() => setIsExtending(!isExtending)}
                      className="text-xs text-blue-600 hover:underline font-bold flex items-center gap-1 cursor-pointer mr-1"
                    >
                      <Clock className="w-3.5 h-3.5" /> تمديد الإقامة
                    </button>
                  </div>
                </div>

                {/* Subform: Add Service Charge */}
                {isAddingCharge && (
                  <form
                    onSubmit={handleAddChargeSubmit}
                    className="p-3 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-700 space-y-2 animate-fadeIn"
                  >
                    <span className="text-xs font-bold text-slate-800 dark:text-slate-200">إضافة رسوم خدمة جديدة:</span>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                      <input
                        type="text"
                        placeholder="البيان (مغسلة، خدمة غرف، ميني بار)"
                        value={chargeDesc}
                        onChange={(e) => setChargeDesc(e.target.value)}
                        required
                        className="sm:col-span-2 px-2.5 py-1.5 text-xs bg-slate-50 dark:bg-slate-800 border rounded"
                      />
                      <input
                        type="number"
                        placeholder={`المبلغ (${settings.currencySymbol})`}
                        value={chargeAmount}
                        onChange={(e) => setChargeAmount(e.target.value)}
                        required
                        min="1"
                        step="any"
                        className="px-2.5 py-1.5 text-xs bg-slate-50 dark:bg-slate-800 border rounded font-mono font-bold"
                      />
                    </div>
                    <div className="flex justify-end gap-2">
                      <button
                        type="button"
                        onClick={() => setIsAddingCharge(false)}
                        className="px-2.5 py-1 text-xs text-slate-400 hover:bg-slate-100 rounded"
                      >
                        إلغاء
                      </button>
                      <button
                        type="submit"
                        className="px-3 py-1 bg-emerald-600 hover:bg-emerald-500 text-white rounded text-xs font-bold"
                      >
                        إضافة
                      </button>
                    </div>
                  </form>
                )}

                {/* Subform: Extend Stay */}
                {isExtending && (
                  <form
                    onSubmit={handleExtendSubmit}
                    className="p-3 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-700 space-y-2 animate-fadeIn"
                  >
                    <span className="text-xs font-bold text-slate-800 dark:text-slate-200">تمديد ليالي الإقامة:</span>
                    <div className="flex items-center gap-2">
                      <input
                        type="number"
                        min="1"
                        max="60"
                        value={extraNights}
                        onChange={(e) => setExtraNights(parseInt(e.target.value) || 1)}
                        className="w-24 px-2.5 py-1.5 text-xs bg-slate-50 dark:bg-slate-800 border rounded font-bold text-center"
                      />
                      <span className="text-xs text-slate-500">ليالي إضافية</span>
                      <div className="mr-auto flex gap-2">
                        <button
                          type="button"
                          onClick={() => setIsExtending(false)}
                          className="px-2.5 py-1 text-xs text-slate-400 hover:bg-slate-100 rounded"
                        >
                          إلغاء
                        </button>
                        <button
                          type="submit"
                          className="px-3 py-1 bg-blue-600 hover:bg-blue-500 text-white rounded text-xs font-bold"
                        >
                          تأكيد التمديد
                        </button>
                      </div>
                    </div>
                  </form>
                )}

                {/* Extra Charges List if any */}
                {(activeBooking.additionalCharges || []).length > 0 && (
                  <div className="space-y-1 text-xs">
                    <span className="text-[11px] text-slate-400">الخدمات الإضافية المسجلة:</span>
                    <div className="divide-y divide-slate-100 dark:divide-slate-800 bg-white dark:bg-slate-900 rounded-lg p-2 border border-slate-200 dark:border-slate-700/60">
                      {activeBooking.additionalCharges?.map((ch) => (
                        <div key={ch.id} className="py-1 flex items-center justify-between text-[11px]">
                          <span className="text-slate-700 dark:text-slate-300">{ch.description}</span>
                          <span className="font-mono font-medium text-slate-900 dark:text-white">
                            +{ch.amount} {settings.currencySymbol}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Total Numbers Grid */}
                <div className="grid grid-cols-3 gap-2 pt-2 border-t border-slate-200 dark:border-slate-700 text-center">
                  <div className="p-2 bg-white dark:bg-slate-900 rounded-lg border border-slate-200 dark:border-slate-800">
                    <span className="text-[11px] text-slate-400 block">إجمالي الحساب:</span>
                    <strong className="text-sm text-slate-900 dark:text-white font-mono">
                      {activeBooking.totalAmount} {settings.currencySymbol}
                    </strong>
                  </div>

                  <div className="p-2 bg-white dark:bg-slate-900 rounded-lg border border-slate-200 dark:border-slate-800">
                    <span className="text-[11px] text-slate-400 block">المبلغ المسدد:</span>
                    <strong className="text-sm text-emerald-600 dark:text-emerald-400 font-mono">
                      {activeBooking.paidAmount} {settings.currencySymbol}
                    </strong>
                  </div>

                  <div
                    className={`p-2 rounded-lg border ${
                      unpaidBalance > 0
                        ? 'bg-rose-50 dark:bg-rose-950/40 border-rose-200 dark:border-rose-900 text-rose-600 dark:text-rose-400'
                        : 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-200 dark:border-emerald-900 text-emerald-600 dark:text-emerald-400'
                    }`}
                  >
                    <span className="text-[11px] block">{unpaidBalance > 0 ? 'المتبقي للتسوية:' : 'الحالة:'}</span>
                    <strong className="text-sm font-mono font-bold">
                      {unpaidBalance > 0 ? `${unpaidBalance} ${settings.currencySymbol}` : 'مدفوع بالكامل'}
                    </strong>
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center justify-between gap-3 pt-2">
                <button
                  onClick={() => generatePdfInvoice(activeBooking)}
                  className="px-3.5 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs font-semibold flex items-center gap-1.5 transition cursor-pointer"
                >
                  <FileText className="w-4 h-4 text-slate-500" />
                  <span>طباعة فاتورة الحجز (PDF)</span>
                </button>

                <button
                  onClick={() => setIsCheckOutConfirm(true)}
                  className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold flex items-center gap-1.5 transition cursor-pointer shadow-sm"
                >
                  <LogOut className="w-4 h-4" />
                  <span>تسجيل خروج النزيل (Check-out)</span>
                </button>
              </div>
            </div>
          )}

          {/* Cleaning State Actions */}
          {selectedRoom.status === 'cleaning' && (
            <div className="p-6 bg-amber-50 dark:bg-amber-950/30 rounded-xl border border-amber-200 dark:border-amber-900/50 text-center space-y-4">
              <div className="w-12 h-12 rounded-full bg-amber-500/20 text-amber-600 dark:text-amber-400 flex items-center justify-center mx-auto">
                <Sparkles className="w-6 h-6" />
              </div>
              <div>
                <h3 className="font-bold text-slate-800 dark:text-slate-200 text-sm">الغرفة بانتظار الهاوس كيبينج</h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 max-w-md mx-auto">
                  تم تسجيل مغادرة النزيل السابق، وتنتظر الغرفة إتمام مهام التنظيف وتغيير الشراشف والتعقيم قبل إعادة
                  إتاحتها للحجز.
                </p>
              </div>

              <button
                onClick={() => {
                  completeHousekeeping(selectedRoom.id);
                  setSelectedRoom(null);
                }}
                className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-xl transition inline-flex items-center gap-2 shadow-md cursor-pointer"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>تم إتمام التنظيف (إعادة الغرفة للمتاح)</span>
              </button>
            </div>
          )}

          {/* Available State View */}
          {selectedRoom.status === 'available' && (
            <div className="space-y-4">
              <div className="p-4 bg-emerald-50 dark:bg-emerald-950/20 rounded-xl border border-emerald-200 dark:border-emerald-900/40 space-y-2 text-xs">
                <div className="flex items-center gap-2 text-emerald-800 dark:text-emerald-300 font-bold">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  الغرفة شاغرة وجاهزة للاستقبال فوراً
                </div>
                <p className="text-slate-600 dark:text-slate-400">
                  تم تنظيف الغرفة وفحصها بالكامل، وهي مهيأة لاستقبال النزلاء الجدد أو الربط مع عميل مسجل.
                </p>
              </div>

              <div className="space-y-2 text-xs">
                <span className="font-semibold text-slate-700 dark:text-slate-300">ميزات الغرفة:</span>
                <div className="flex flex-wrap gap-2">
                  {selectedRoom.features.map((f, i) => (
                    <span
                      key={i}
                      className="px-2.5 py-1 rounded-md bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700"
                    >
                      {f}
                    </span>
                  ))}
                </div>
              </div>

              {/* Action Bar */}
              <div className="pt-2 flex flex-wrap items-center justify-between gap-2 border-t border-slate-100 dark:border-slate-800">
                {/* Delete Room option */}
                {isDeleteConfirm ? (
                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => setIsDeleteConfirm(false)}
                      className="px-2.5 py-1.5 text-xs text-slate-500 hover:bg-slate-100 rounded-lg"
                    >
                      إلغاء
                    </button>
                    <button
                      onClick={handleDeleteRoom}
                      className="px-3 py-1.5 bg-rose-600 hover:bg-rose-500 text-white rounded-lg text-xs font-bold"
                    >
                      تأكيد حذف الغرفة
                    </button>
                  </div>
                ) : (
                  <button
                    onClick={() => setIsDeleteConfirm(true)}
                    className="px-3 py-2 text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-xl text-xs font-semibold flex items-center gap-1 transition cursor-pointer"
                  >
                    <Trash2 className="w-4 h-4" />
                    <span>حذف الغرفة</span>
                  </button>
                )}

                <div className="flex items-center gap-2">
                  <button
                    onClick={handleOpenLinkModal}
                    className="px-4 py-2.5 bg-slate-900 dark:bg-slate-800 hover:bg-slate-800 text-white rounded-xl text-xs font-bold flex items-center gap-2 shadow-sm transition cursor-pointer"
                  >
                    <ArrowLeftRight className="w-4 h-4 text-emerald-400" />
                    <span>ربط عميل بالغرفة</span>
                  </button>

                  <button
                    onClick={() => {
                      setIsCheckInModalOpen(true);
                    }}
                    className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold flex items-center gap-2 shadow-md transition cursor-pointer"
                  >
                    <Plus className="w-4 h-4" />
                    <span>تسجيل دخول فوري (Check-in)</span>
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Maintenance State */}
          {selectedRoom.status === 'maintenance' && (
            <div className="p-6 bg-purple-50 dark:bg-purple-950/30 rounded-xl border border-purple-200 dark:border-purple-900/50 text-center space-y-3">
              <Wrench className="w-8 h-8 text-purple-600 dark:text-purple-400 mx-auto" />
              <h3 className="font-bold text-slate-800 dark:text-slate-200 text-sm">الغرفة تحت الصيانة</h3>
              <p className="text-xs text-slate-500">{selectedRoom.notes || 'أعمال صيانة وتجهيز فني'}</p>
              <button
                onClick={() => updateRoomStatus(selectedRoom.id, 'cleaning')}
                className="px-4 py-2 bg-purple-600 text-white text-xs font-bold rounded-lg hover:bg-purple-500 transition cursor-pointer"
              >
                اكتمال الصيانة وتحويلها للتنظيف
              </button>
            </div>
          )}
        </div>

        {/* Check-Out Settlement Confirmation Modal */}
        {isCheckOutConfirm && (
          <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-xs">
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 max-w-md w-full shadow-2xl space-y-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-rose-500/10 text-rose-600 flex items-center justify-center shrink-0">
                  <LogOut className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-sm text-slate-900 dark:text-white">
                    تأكيد تسجيل مغادرة الغرفة {selectedRoom.roomNumber}
                  </h3>
                  <p className="text-xs text-slate-500">سيتم نقل الغرفة مباشرة إلى قائمة الهاوس كيبينج (التنظيف).</p>
                </div>
              </div>

              {unpaidBalance > 0 ? (
                <div className="p-3 bg-rose-50 dark:bg-rose-950/40 rounded-xl border border-rose-200 dark:border-rose-900 space-y-2 text-xs">
                  <div className="flex items-center justify-between font-semibold text-rose-800 dark:text-rose-300">
                    <span>المبلغ المتبقي للتحصيل:</span>
                    <span className="text-base font-bold font-mono">
                      {unpaidBalance} {settings.currencySymbol}
                    </span>
                  </div>

                  <div>
                    <label className="text-[11px] text-slate-500 block mb-1">طريقة السداد الآن:</label>
                    <select
                      value={settleMethod}
                      onChange={(e) => setSettleMethod(e.target.value as PaymentMethod)}
                      className="w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded px-2.5 py-1.5 text-xs focus:outline-none"
                    >
                      <option value="card">💳 بطاقة مدى / ائتمانية (Card)</option>
                      <option value="cash">💵 نقداً (Cash)</option>
                      <option value="transfer">🏦 تحويل بنكي (Transfer)</option>
                    </select>
                  </div>
                </div>
              ) : (
                <div className="p-3 bg-emerald-50 dark:bg-emerald-950/40 rounded-xl border border-emerald-200 dark:border-emerald-900 text-xs text-emerald-800 dark:text-emerald-300 flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>تم تسديد كافة مستحقات الإقامة والخدمات بالكامل (رصيد مسوّى).</span>
                </div>
              )}

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsCheckOutConfirm(false)}
                  className="px-3 py-1.5 text-xs text-slate-600 dark:text-slate-400 hover:bg-slate-100 rounded-lg"
                >
                  تراجع
                </button>
                <button
                  type="button"
                  onClick={handleConfirmCheckOut}
                  className="px-4 py-2 bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold rounded-lg transition"
                >
                  تأكيد المغادرة وإغلاق الحجز
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
