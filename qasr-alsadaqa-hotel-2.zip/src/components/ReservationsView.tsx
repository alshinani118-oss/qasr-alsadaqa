import React, { useState } from 'react';
import { useHotel } from '../context/HotelContext';
import {
  Calendar,
  Search,
  Plus,
  Filter,
  CheckCircle2,
  Clock,
  User,
  Phone,
  DoorOpen,
  DollarSign,
  FileText,
  AlertCircle,
  ChevronLeft,
  ChevronRight,
  ArrowUpRight,
  Printer,
  CalendarDays,
  CreditCard,
  Ban,
} from 'lucide-react';
import { Booking } from '../types/hotel';
import { localDate } from '../utils/dates';
import { FutureReservationsPanel } from './FutureReservationsPanel';

export const ReservationsView: React.FC = () => {
  const {
    bookings,
    rooms,
    guests,
    settings,
    setIsCheckInModalOpen,
    generatePdfInvoice,
    cancelBooking,
    extendBookingNights,
    setSelectedRoom,
  } = useHotel();

  const [filterStatus, setFilterStatus] = useState<'all' | 'active' | 'today_checkout' | 'completed'>('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedBooking, setSelectedBooking] = useState<Booking | null>(null);
  const [extendModalBooking, setExtendModalBooking] = useState<Booking | null>(null);
  const [extraNights, setExtraNights] = useState<number>(1);

  const todayStr = localDate();

  const filteredBookings = bookings.filter((b) => {
    // Status filter
    if (filterStatus === 'active' && !b.isActive) return false;
    if (filterStatus === 'completed' && b.isActive) return false;
    if (filterStatus === 'today_checkout' && (!b.isActive || b.expectedCheckOutDate.substring(0, 10) !== todayStr)) {
      return false;
    }

    // Search query
    if (searchTerm) {
      const q = searchTerm.toLowerCase();
      return (
        b.bookingCode.toLowerCase().includes(q) ||
        b.roomNumber.toLowerCase().includes(q) ||
        b.guestName.toLowerCase().includes(q) ||
        b.guestPhone.includes(q) ||
        b.guestNationalId.includes(q)
      );
    }
    return true;
  });

  const activeCount = bookings.filter((b) => b.isActive).length;
  const checkoutTodayCount = bookings.filter(
    (b) => b.isActive && b.expectedCheckOutDate.substring(0, 10) === todayStr
  ).length;
  const completedCount = bookings.filter((b) => !b.isActive).length;

  return (
    <div className="space-y-6 animate-fadeIn" dir="rtl">
      <FutureReservationsPanel />

      {/* Top Banner & Stats */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 sm:p-6 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-sky-500/10 text-sky-500">
              <CalendarDays className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-lg sm:text-xl font-bold text-slate-800 dark:text-slate-100">
                إدارة الحجوزات والتسكين (Bookings & Reservations)
              </h2>
              <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400">
                متابعة الحجوزات النشطة والمغادرات وتمديد الإقامة وإصدار السندات الضريبية
              </p>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2 self-stretch sm:self-auto">
          <button
            onClick={() => setIsCheckInModalOpen(true)}
            className="flex-1 sm:flex-none flex items-center justify-center gap-2 bg-sky-600 hover:bg-sky-500 text-white px-4 py-2.5 rounded-xl font-semibold text-sm shadow-md transition cursor-pointer active:scale-95"
          >
            <Plus className="w-4 h-4" />
            <span>حجز وتسكين جديد</span>
          </button>
        </div>
      </div>

      {/* Filter Tabs & Search Bar */}
      <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
        {/* Pills */}
        <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pb-1">
          <button
            onClick={() => setFilterStatus('all')}
            className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-medium transition cursor-pointer whitespace-nowrap ${
              filterStatus === 'all'
                ? 'bg-sky-600 text-white shadow-sm font-semibold'
                : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-800'
            }`}
          >
            جميع الحجوزات ({bookings.length})
          </button>

          <button
            onClick={() => setFilterStatus('active')}
            className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-medium transition cursor-pointer whitespace-nowrap flex items-center gap-1.5 ${
              filterStatus === 'active'
                ? 'bg-emerald-600 text-white shadow-sm font-semibold'
                : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-800'
            }`}
          >
            <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
            حجوزات نشطة ({activeCount})
          </button>

          <button
            onClick={() => setFilterStatus('today_checkout')}
            className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-medium transition cursor-pointer whitespace-nowrap flex items-center gap-1.5 ${
              filterStatus === 'today_checkout'
                ? 'bg-amber-600 text-white shadow-sm font-semibold'
                : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-800'
            }`}
          >
            <Clock className="w-3.5 h-3.5" />
            مغادرات متوقعة اليوم ({checkoutTodayCount})
          </button>

          <button
            onClick={() => setFilterStatus('completed')}
            className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-medium transition cursor-pointer whitespace-nowrap ${
              filterStatus === 'completed'
                ? 'bg-slate-800 text-white shadow-sm font-semibold'
                : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-800'
            }`}
          >
            حجوزات منتهية ({completedCount})
          </button>
        </div>

        {/* Search Input */}
        <div className="relative w-full md:w-80">
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="بحث برقم الحجز، الغرفة، اسم النزيل، الهاتف..."
            className="w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-800 dark:text-slate-200 text-xs sm:text-sm rounded-xl pl-4 pr-10 py-2.5 focus:outline-none focus:border-sky-500 shadow-sm"
          />
          <Search className="w-4 h-4 text-slate-400 absolute right-3.5 top-3" />
        </div>
      </div>

      {/* Bookings Table / Cards Grid */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
        {filteredBookings.length === 0 ? (
          <div className="p-12 text-center text-slate-400">
            <Calendar className="w-12 h-12 mx-auto mb-3 opacity-30 text-sky-500" />
            <p className="text-base font-semibold">لا توجد حجوزات مطابقة لمعايير البحث</p>
            <p className="text-xs text-slate-500 mt-1">يمكنك إضافة حجز وتسكين جديد بنقرة زر أعلاه</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-right text-xs sm:text-sm">
              <thead className="bg-slate-50 dark:bg-slate-950 text-slate-500 dark:text-slate-400 border-b border-slate-200 dark:border-slate-800 font-semibold">
                <tr>
                  <th className="py-3 px-4">رقم الحجز</th>
                  <th className="py-3 px-4">الغرفة</th>
                  <th className="py-3 px-4">النزيل</th>
                  <th className="py-3 px-4">تاريخ الدخول</th>
                  <th className="py-3 px-4">تاريخ الخروج</th>
                  <th className="py-3 px-4">الليالي</th>
                  <th className="py-3 px-4">الإجمالي</th>
                  <th className="py-3 px-4">حالة السداد</th>
                  <th className="py-3 px-4 text-center">الإجراءات</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {filteredBookings.map((b) => {
                  const isCheckoutToday = b.isActive && b.expectedCheckOutDate.substring(0, 10) === todayStr;
                  const isOverdue = b.isActive && b.expectedCheckOutDate.substring(0, 10) < todayStr;

                  return (
                    <tr
                      key={b.id}
                      className="hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition group"
                    >
                      {/* Booking Code */}
                      <td className="py-3.5 px-4 font-mono font-bold text-sky-600 dark:text-sky-400">
                        {b.bookingCode}
                        {b.isActive && (
                          <span className="block text-[10px] text-emerald-500 font-sans font-medium">
                            إقامة نشطة
                          </span>
                        )}
                      </td>

                      {/* Room Number */}
                      <td className="py-3.5 px-4">
                        <button
                          onClick={() => {
                            const r = rooms.find((rm) => rm.id === b.roomId);
                            if (r) setSelectedRoom(r);
                          }}
                          className="inline-flex items-center gap-1.5 font-bold text-slate-800 dark:text-slate-100 hover:text-sky-500 transition cursor-pointer"
                        >
                          <DoorOpen className="w-4 h-4 text-sky-500" />
                          <span>#{b.roomNumber}</span>
                        </button>
                      </td>

                      {/* Guest Info */}
                      <td className="py-3.5 px-4">
                        <div className="font-semibold text-slate-800 dark:text-slate-100">{b.guestName}</div>
                        <div className="text-[11px] text-slate-400 font-mono flex items-center gap-1 mt-0.5" dir="ltr">
                          <Phone className="w-3 h-3 text-slate-400 shrink-0" />
                          <span>{b.guestPhone}</span>
                        </div>
                      </td>

                      {/* Check-In */}
                      <td className="py-3.5 px-4 text-slate-600 dark:text-slate-300 font-mono text-xs">
                        {b.checkInDate}
                      </td>

                      {/* Expected Check-Out */}
                      <td className="py-3.5 px-4 font-mono text-xs">
                        <span
                          className={
                            isOverdue
                              ? 'text-rose-500 font-bold bg-rose-50 dark:bg-rose-950/40 px-2 py-0.5 rounded'
                              : isCheckoutToday
                              ? 'text-amber-600 font-bold bg-amber-50 dark:bg-amber-950/40 px-2 py-0.5 rounded'
                              : 'text-slate-600 dark:text-slate-300'
                          }
                        >
                          {b.expectedCheckOutDate}
                        </span>
                      </td>

                      {/* Nights */}
                      <td className="py-3.5 px-4 font-semibold text-slate-700 dark:text-slate-300">
                        {b.nights} ليالي
                      </td>

                      {/* Total Amount */}
                      <td className="py-3.5 px-4 font-bold text-slate-900 dark:text-slate-100 font-mono">
                        {b.totalAmount} {settings.currencySymbol}
                        {b.additionalCharges.length > 0 && (
                          <span className="block text-[10px] text-sky-500 font-normal">
                            +{b.additionalCharges.reduce((s, c) => s + c.amount, 0)} خدمات إضافية
                          </span>
                        )}
                      </td>

                      {/* Payment Status */}
                      <td className="py-3.5 px-4">
                        {b.paymentStatus === 'paid' ? (
                          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-800/60">
                            <CheckCircle2 className="w-3 h-3" />
                            مسدد بالكامل
                          </span>
                        ) : b.paymentStatus === 'partial' ? (
                          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold bg-amber-50 dark:bg-amber-950/40 text-amber-600 dark:text-amber-400 border border-amber-200 dark:border-amber-800/60">
                            <Clock className="w-3 h-3" />
                            دفعة جزئية (متبقي {b.totalAmount - b.paidAmount} ر.ي)
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold bg-rose-50 dark:bg-rose-950/40 text-rose-600 dark:text-rose-400 border border-rose-200 dark:border-rose-800/60">
                            <AlertCircle className="w-3 h-3" />
                            غير مسدد
                          </span>
                        )}
                      </td>

                      {/* Actions */}
                      <td className="py-3.5 px-4 text-center">
                        <div className="flex items-center justify-center gap-1.5">
                          {/* Invoice Voucher PDF */}
                          <button
                            onClick={() => generatePdfInvoice(b)}
                            title="طباعة الفاتورة وسند الحجز PDF"
                            className="p-2 text-slate-500 hover:text-sky-600 bg-slate-100 hover:bg-sky-50 dark:bg-slate-800 dark:hover:bg-sky-950/40 rounded-lg transition cursor-pointer"
                          >
                            <Printer className="w-4 h-4" />
                          </button>

                          {/* Extend Stay */}
                          {b.isActive && (
                            <button
                              onClick={() => {
                                setExtendModalBooking(b);
                                setExtraNights(1);
                              }}
                              title="تمديد ليالي الإقامة"
                              className="p-2 text-slate-500 hover:text-emerald-600 bg-slate-100 hover:bg-emerald-50 dark:bg-slate-800 dark:hover:bg-emerald-950/40 rounded-lg transition cursor-pointer"
                            >
                              <Plus className="w-4 h-4" />
                            </button>
                          )}

                          {/* Cancel Booking */}
                          {b.isActive && (
                            <button
                              onClick={() => {
                                if (window.confirm(`هل أنت متأكد من إلغاء الحجز #${b.bookingCode} للغرفة ${b.roomNumber}؟`)) {
                                  cancelBooking(b.id);
                                }
                              }}
                              title="إلغاء الحجز"
                              className="p-2 text-slate-500 hover:text-rose-600 bg-slate-100 hover:bg-rose-50 dark:bg-slate-800 dark:hover:bg-rose-950/40 rounded-lg transition cursor-pointer"
                            >
                              <Ban className="w-4 h-4" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Extend Stay Modal */}
      {extendModalBooking && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4" dir="rtl">
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 w-full max-w-md border border-slate-200 dark:border-slate-800 shadow-2xl space-y-5 animate-scaleUp">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-bold text-slate-800 dark:text-slate-100">
                تمديد إقامة النزيل (Extend Stay)
              </h3>
              <button
                onClick={() => setExtendModalBooking(null)}
                className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
              >
                ✕
              </button>
            </div>

            <div className="p-3.5 bg-slate-50 dark:bg-slate-800/60 rounded-2xl text-xs space-y-1.5">
              <p>
                <strong>النزيل:</strong> {extendModalBooking.guestName}
              </p>
              <p>
                <strong>الغرفة:</strong> #{extendModalBooking.roomNumber}
              </p>
              <p>
                <strong>سعر الليلة:</strong> {extendModalBooking.pricePerNight} {settings.currencySymbol}
              </p>
              <p>
                <strong>تاريخ الخروج الحالي:</strong> {extendModalBooking.expectedCheckOutDate}
              </p>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1.5">
                عدد الليالي الإضافية المطلوبة:
              </label>
              <div className="flex items-center gap-3">
                <button
                  type="button"
                  onClick={() => setExtraNights((prev) => Math.max(1, prev - 1))}
                  className="w-10 h-10 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 font-bold text-lg cursor-pointer"
                >
                  -
                </button>
                <input
                  type="number"
                  min="1"
                  value={extraNights}
                  onChange={(e) => setExtraNights(Math.max(1, parseInt(e.target.value, 10) || 1))}
                  className="w-20 text-center py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-bold font-mono text-base"
                />
                <button
                  type="button"
                  onClick={() => setExtraNights((prev) => prev + 1)}
                  className="w-10 h-10 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 font-bold text-lg cursor-pointer"
                >
                  +
                </button>
              </div>
            </div>

            <div className="p-3 bg-sky-50 dark:bg-sky-950/40 rounded-xl text-xs text-sky-700 dark:text-sky-300">
              المبلغ الإضافي المحتسب: <strong>{extraNights * extendModalBooking.pricePerNight} {settings.currencySymbol}</strong>
            </div>

            <div className="flex items-center gap-3 pt-2">
              <button
                type="button"
                onClick={() => {
                  extendBookingNights(extendModalBooking.id, extraNights);
                  setExtendModalBooking(null);
                }}
                className="flex-1 py-2.5 rounded-xl bg-sky-600 hover:bg-sky-500 text-white font-semibold text-sm shadow-md transition cursor-pointer"
              >
                تأكيد التمديد
              </button>
              <button
                type="button"
                onClick={() => setExtendModalBooking(null)}
                className="px-4 py-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 text-sm font-medium hover:bg-slate-200 transition cursor-pointer"
              >
                إلغاء
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
