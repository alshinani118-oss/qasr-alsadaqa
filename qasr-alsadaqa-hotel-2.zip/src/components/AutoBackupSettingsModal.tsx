import React, { useState } from 'react';
import { useHotel } from '../context/HotelContext';
import {
  X,
  Clock,
  HardDrive,
  Cloud,
  CheckCircle2,
  AlertTriangle,
  Play,
  RotateCcw,
  Sliders,
  ShieldCheck,
  Calendar,
  Layers,
  Database,
  ArrowRightLeft,
  ExternalLink,
  Plus,
  RefreshCw,
  Sparkles,
} from 'lucide-react';
import { AutoBackupFrequency } from '../types/hotel';

export const AutoBackupSettingsModal: React.FC = () => {
  const {
    isAutoBackupModalOpen,
    setIsAutoBackupModalOpen,
    autoBackupConfig,
    updateAutoBackupConfig,
    backupSnapshots,
    createBackupSnapshot,
    restoreBackupSnapshot,
    selectedGoogleAccount,
    setIsGoogleDriveLinkModalOpen,
    isSyncingToGoogleDrive,
    playAlertSound,
  } = useHotel();

  const [isSaving, setIsSaving] = useState<boolean>(false);
  const [successMessage, setSuccessMessage] = useState<string>('');
  const [confirmRestoreId, setConfirmRestoreId] = useState<string | null>(null);

  if (!isAutoBackupModalOpen) return null;

  const frequencies: { id: AutoBackupFrequency; label: string; desc: string; badge?: string }[] = [
    { id: '1h', label: 'كل 1 ساعة', desc: 'مناسب للفنادق عالية الكثافة والحجوزات المستمرة' },
    { id: '3h', label: 'كل 3 ساعات', desc: 'تحديث دوري متكرر لقاعدة البيانات' },
    { id: '6h', label: 'كل 6 ساعات', desc: 'الخيار الموصى به لتحقيق التوازن والأداء', badge: 'موصى به' },
    { id: '12h', label: 'كل 12 ساعة', desc: 'مرتين يومياً (نهاية كل شفت عمل)' },
    { id: '24h', label: 'يومياً (24 ساعة)', desc: 'نسخة يومية مع إقفال الصندوق' },
    { id: 'weekly', label: 'أسبوعياً', desc: 'أرشيف أسبوعي مجمع' },
  ];

  const handleToggleEnabled = (enabled: boolean) => {
    updateAutoBackupConfig({ enabled });
    setSuccessMessage(enabled ? 'تم تفعيل النسخ الاحتياطي التلقائي بنجاح' : 'تم تعطيل النسخ الاحتياطي التلقائي');
    setTimeout(() => setSuccessMessage(''), 2500);
  };

  const handleFrequencyChange = (frequency: AutoBackupFrequency) => {
    updateAutoBackupConfig({ frequency });
    setSuccessMessage(`تم ضبط تكرار النسخ التلقائي: ${frequencies.find((f) => f.id === frequency)?.label}`);
    setTimeout(() => setSuccessMessage(''), 2500);
  };

  const handleCreateInstant = async () => {
    setIsSaving(true);
    await createBackupSnapshot('manual');
    setIsSaving(false);
    setSuccessMessage('تم إنشاء نسخة احتياطية فورية وحفظها بنجاح');
    setTimeout(() => setSuccessMessage(''), 2500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4" dir="rtl">
      {/* Backdrop */}
      <div
        onClick={() => setIsAutoBackupModalOpen(false)}
        className="fixed inset-0 bg-slate-950/70 backdrop-blur-sm transition-opacity"
      />

      {/* Modal Container */}
      <div className="relative w-full max-w-4xl bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 flex flex-col max-h-[92vh] overflow-hidden z-10 text-slate-900 dark:text-slate-100 animate-fadeIn">
        {/* Header */}
        <div className="px-5 py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between bg-gradient-to-r from-emerald-600 via-teal-600 to-sky-700 text-white shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-white/20 backdrop-blur-md flex items-center justify-center text-white shadow-inner">
              <Clock className="w-6 h-6 stroke-[2]" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-bold">إعدادات وجدولة النسخ الاحتياطي التلقائي</h2>
                <span
                  className={`px-2 py-0.5 rounded-full text-[11px] font-bold ${
                    autoBackupConfig.enabled
                      ? 'bg-emerald-400 text-emerald-950'
                      : 'bg-slate-800/60 text-slate-200'
                  }`}
                >
                  {autoBackupConfig.enabled ? 'النسخ التلقائي نشط' : 'النسخ التلقائي معطل'}
                </span>
              </div>
              <p className="text-xs text-teal-100">
                حماية بيانات الفندق والـ SQLite والمزامنة السحابية مع Google Drive
              </p>
            </div>
          </div>

          <button
            onClick={() => setIsAutoBackupModalOpen(false)}
            className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white transition cursor-pointer"
            aria-label="إغلاق"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Feedback alert */}
        {successMessage && (
          <div className="bg-emerald-50 dark:bg-emerald-950/60 border-b border-emerald-200 dark:border-emerald-800/60 px-5 py-2.5 text-xs text-emerald-800 dark:text-emerald-300 flex items-center gap-2 font-semibold animate-fadeIn">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            <span>{successMessage}</span>
          </div>
        )}

        {/* Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6">
          {/* Top Master Switch Card */}
          <div className="bg-slate-50 dark:bg-slate-800/50 rounded-2xl p-4 sm:p-5 border border-slate-200 dark:border-slate-700 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
                <h3 className="text-sm sm:text-base font-bold text-slate-800 dark:text-slate-100">
                  محرك النسخ الاحتياطي التلقائي في الخلفية (Background Engine)
                </h3>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                يقوم النظام بالتقاط لقطات دورية كاملة للبيانات وحفظها وتمريرها إلى سحابة Google Drive المختارة.
              </p>
            </div>

            <div className="flex items-center gap-3">
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={autoBackupConfig.enabled}
                  onChange={(e) => handleToggleEnabled(e.target.checked)}
                  className="sr-only peer"
                />
                <div className="w-14 h-7 bg-slate-300 dark:bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[4px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-6 after:w-6 after:transition-all peer-checked:bg-emerald-600"></div>
              </label>
              <span className="text-xs font-bold text-slate-700 dark:text-slate-200">
                {autoBackupConfig.enabled ? 'مفعل' : 'معطل'}
              </span>
            </div>
          </div>

          {/* Scheduling Timer & Status Monitor */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="bg-white dark:bg-slate-800 p-4 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
              <span className="text-xs text-slate-500 dark:text-slate-400 block mb-1">حالة الجدولة التلقائية:</span>
              <div className="flex items-center gap-2">
                <span
                  className={`w-2.5 h-2.5 rounded-full ${
                    autoBackupConfig.enabled ? 'bg-emerald-500 animate-ping' : 'bg-slate-400'
                  }`}
                />
                <span className="font-bold text-sm text-slate-800 dark:text-slate-100">
                  {autoBackupConfig.enabled ? 'نشط ويعمل بالخلفية' : 'متوقف مؤقتاً'}
                </span>
              </div>
            </div>

            <div className="bg-white dark:bg-slate-800 p-4 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
              <span className="text-xs text-slate-500 dark:text-slate-400 block mb-1">آخر عملية نسخ مكتملة:</span>
              <span className="font-mono text-xs font-semibold text-slate-700 dark:text-slate-200 block truncate">
                {autoBackupConfig.lastBackupTime || 'لم يتم التسجيل بعد'}
              </span>
            </div>

            <div className="bg-white dark:bg-slate-800 p-4 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
              <span className="text-xs text-slate-500 dark:text-slate-400 block mb-1">موعد النسخ القادم المتوقع:</span>
              <span className="font-mono text-xs font-semibold text-emerald-600 dark:text-emerald-400 block truncate">
                {autoBackupConfig.enabled ? autoBackupConfig.nextBackupTime || 'خلال دقائق' : 'معطل'}
              </span>
            </div>
          </div>

          {/* SECTION: Frequency Selector */}
          <div className="space-y-3">
            <h3 className="text-sm font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2">
              <Sliders className="w-4 h-4 text-emerald-600" />
              تكرار ودورية النسخ الاحتياطي (Backup Frequency):
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
              {frequencies.map((f) => {
                const isSelected = autoBackupConfig.frequency === f.id;

                return (
                  <button
                    key={f.id}
                    type="button"
                    onClick={() => handleFrequencyChange(f.id)}
                    className={`p-3.5 rounded-xl border text-right transition-all cursor-pointer relative ${
                      isSelected
                        ? 'bg-emerald-50/90 dark:bg-emerald-950/40 border-emerald-500 ring-2 ring-emerald-500/20 shadow-sm'
                        : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 hover:border-emerald-300 dark:hover:border-emerald-800'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-2 mb-1">
                      <span
                        className={`text-sm font-bold ${
                          isSelected ? 'text-emerald-700 dark:text-emerald-400' : 'text-slate-800 dark:text-slate-100'
                        }`}
                      >
                        {f.label}
                      </span>
                      {f.badge && (
                        <span className="px-2 py-0.5 rounded-full bg-emerald-600 text-white text-[10px] font-bold">
                          {f.badge}
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">{f.desc}</p>
                  </button>
                );
              })}
            </div>
          </div>

          {/* SECTION: Scope & Google Drive Link Info */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Backup Scope Checkboxes */}
            <div className="bg-slate-50 dark:bg-slate-800/50 p-4 rounded-xl border border-slate-200 dark:border-slate-700 space-y-3">
              <h4 className="text-xs font-bold text-slate-700 dark:text-slate-200 flex items-center gap-1.5">
                <Database className="w-4 h-4 text-sky-600" />
                محتويات حزمة النسخ الاحتياطي (Scope):
              </h4>

              <div className="space-y-2 text-xs">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={autoBackupConfig.includeSqliteDb}
                    onChange={(e) => updateAutoBackupConfig({ includeSqliteDb: e.target.checked })}
                    className="w-4 h-4 rounded text-emerald-600 focus:ring-emerald-500"
                  />
                  <span>جداول SQLite الأساسية (الغرف، النزلاء، الحجوزات، المدفوعات)</span>
                </label>

                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={autoBackupConfig.includeFinance}
                    onChange={(e) => updateAutoBackupConfig({ includeFinance: e.target.checked })}
                    className="w-4 h-4 rounded text-emerald-600 focus:ring-emerald-500"
                  />
                  <span>السجلات المالية (المصروفات، الإيرادات، مسير رواتب الموظفين)</span>
                </label>

                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={autoBackupConfig.includeRoomService}
                    onChange={(e) => updateAutoBackupConfig({ includeRoomService: e.target.checked })}
                    className="w-4 h-4 rounded text-emerald-600 focus:ring-emerald-500"
                  />
                  <span>خدمة الغرف (قائمة المنيو والطلبات الحالية والسابقة)</span>
                </label>

                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={autoBackupConfig.includeLogs}
                    onChange={(e) => updateAutoBackupConfig({ includeLogs: e.target.checked })}
                    className="w-4 h-4 rounded text-emerald-600 focus:ring-emerald-500"
                  />
                  <span>سجلات النشاط والتدقيق الأمني (Activity Logs)</span>
                </label>
              </div>
            </div>

            {/* Google Drive Link Status Card */}
            <div className="bg-slate-50 dark:bg-slate-800/50 p-4 rounded-xl border border-slate-200 dark:border-slate-700 space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-bold text-slate-700 dark:text-slate-200 flex items-center gap-1.5">
                  <Cloud className="w-4 h-4 text-sky-600" />
                  المزامنة مع Google Drive:
                </h4>

                <button
                  type="button"
                  onClick={() => {
                    setIsAutoBackupModalOpen(false);
                    setIsGoogleDriveLinkModalOpen(true);
                  }}
                  className="text-[11px] font-bold text-sky-600 hover:text-sky-700 hover:underline flex items-center gap-1 cursor-pointer"
                >
                  إدارة الحسابات
                  <ExternalLink className="w-3 h-3" />
                </button>
              </div>

              {selectedGoogleAccount ? (
                <div className="bg-white dark:bg-slate-900 p-3 rounded-lg border border-slate-200 dark:border-slate-700 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-xs text-slate-800 dark:text-slate-100">
                      {selectedGoogleAccount.displayName}
                    </span>
                    <span className="px-2 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 text-[10px] font-bold">
                      حساب نشط
                    </span>
                  </div>
                  <span className="font-mono text-xs text-slate-500 block" dir="ltr">
                    {selectedGoogleAccount.email}
                  </span>
                  <div className="text-[11px] text-slate-400">
                    مجلد التخزين: <span className="font-mono text-sky-600">{selectedGoogleAccount.folderName}</span>
                  </div>
                </div>
              ) : (
                <div className="p-3 bg-amber-50 dark:bg-amber-950/40 rounded-lg text-amber-700 dark:text-amber-300 text-xs">
                  لا يوجد حساب Google Drive مرتبط حالياً.
                </div>
              )}

              <label className="flex items-center gap-2 cursor-pointer text-xs">
                <input
                  type="checkbox"
                  checked={autoBackupConfig.syncToGoogleDrive}
                  onChange={(e) => updateAutoBackupConfig({ syncToGoogleDrive: e.target.checked })}
                  className="w-4 h-4 rounded text-sky-600 focus:ring-sky-500"
                />
                <span className="font-medium text-slate-700 dark:text-slate-200">
                  رفع ومزامنة النسخ التلقائية فوراً إلى حساب Google Drive المختار
                </span>
              </label>
            </div>
          </div>

          {/* SECTION: Quick Actions */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-2">
            <button
              type="button"
              disabled={isSaving}
              onClick={handleCreateInstant}
              className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-md transition cursor-pointer active:scale-95 disabled:opacity-50"
            >
              <Play className="w-4 h-4" />
              إنشاء وحفظ نسخة احتياطية فورية الآن
            </button>

            <button
              type="button"
              onClick={() => {
                setIsAutoBackupModalOpen(false);
                setIsGoogleDriveLinkModalOpen(true);
              }}
              className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-sky-50 dark:bg-sky-950/50 hover:bg-sky-100 text-sky-700 dark:text-sky-300 border border-sky-200 dark:border-sky-800 text-xs font-bold transition cursor-pointer"
            >
              <Cloud className="w-4 h-4" />
              فتح سحابة Google Drive وتبديل الحساب
            </button>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 flex items-center justify-between gap-3 shrink-0">
          <span className="text-xs text-slate-500 dark:text-slate-400">
            يتم الاحتفاظ بآخر {autoBackupConfig.retentionCount || 10} نسخ تلقائياً في السجل المحلي والسحابي
          </span>

          <button
            type="button"
            onClick={() => setIsAutoBackupModalOpen(false)}
            className="px-5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold transition cursor-pointer"
          >
            إغلاق
          </button>
        </div>
      </div>
    </div>
  );
};
