import React, { useState } from 'react';
import { UserCog, UserMinus, UserPlus, UserCheck, Pencil, Save, X } from 'lucide-react';
import { useHotel } from '../context/HotelContext';
import { StaffMember, StaffRole } from '../types/hotel';
import { localDate } from '../utils/dates';

const inputCls =
  'w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg px-3 py-2 text-xs sm:text-sm text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-sky-500';
const labelCls = 'block text-[11px] font-semibold text-slate-500 mb-1';

const ROLE_OPTIONS: { value: StaffRole; label: string }[] = [
  { value: 'manager', label: 'مدير' },
  { value: 'receptionist', label: 'استقبال' },
  { value: 'housekeeper', label: 'عامل نظافة / هاوس كيبينج' },
  { value: 'chef', label: 'مطبخ / طباخ' },
  { value: 'maintenance', label: 'صيانة' },
  { value: 'accountant', label: 'محاسب' },
  { value: 'security', label: 'أمن / حارس' },
];

export const AccountManageTab: React.FC = () => {
  const { systemProfiles, updateSystemProfile, staffMembers, updateStaffMember, addStaffMember } = useHotel();

  // ---- system accounts (general manager / reception) ----
  const [editingProfile, setEditingProfile] = useState<'admin' | 'reception' | null>(null);
  const [pf, setPf] = useState({ name: '', roleAr: '', phone: '', email: '', shift: '' });

  const startEditProfile = (kind: 'admin' | 'reception') => {
    const u = systemProfiles[kind];
    setPf({ name: u.name, roleAr: u.roleAr, phone: u.phone, email: u.email, shift: u.shift });
    setEditingProfile(kind);
  };
  const saveProfile = () => {
    if (!editingProfile) return;
    if (!pf.name.trim()) return alert('الاسم مطلوب.');
    updateSystemProfile(editingProfile, {
      name: pf.name.trim(),
      roleAr: pf.roleAr.trim() || systemProfiles[editingProfile].roleAr,
      phone: pf.phone.trim(),
      email: pf.email.trim(),
      shift: pf.shift.trim() || systemProfiles[editingProfile].shift,
    });
    setEditingProfile(null);
  };

  // ---- hotel staff ----
  const [editingStaff, setEditingStaff] = useState<number | 'new' | null>(null);
  const [sf, setSf] = useState({ name: '', roleTitleAr: '', role: 'receptionist' as StaffRole, phone: '', nationalId: '', monthlySalary: 0, status: 'active' as StaffMember['status'] });
  const [showResigned, setShowResigned] = useState(false);

  const startEditStaff = (s: StaffMember) => {
    setSf({ name: s.name, roleTitleAr: s.roleTitleAr, role: s.role, phone: s.phone, nationalId: s.nationalId, monthlySalary: s.monthlySalary, status: s.status });
    setEditingStaff(s.id);
  };
  const startNewStaff = () => {
    setSf({ name: '', roleTitleAr: '', role: 'receptionist', phone: '', nationalId: '', monthlySalary: 0, status: 'active' });
    setEditingStaff('new');
  };
  const saveStaff = () => {
    if (!sf.name.trim()) return alert('اسم الموظف مطلوب.');
    const salary = Math.max(0, Number(sf.monthlySalary) || 0);
    if (editingStaff === 'new') {
      addStaffMember({
        name: sf.name.trim(),
        role: sf.role,
        roleTitleAr: sf.roleTitleAr.trim() || ROLE_OPTIONS.find((r) => r.value === sf.role)?.label || '',
        phone: sf.phone.trim(),
        nationalId: sf.nationalId.trim(),
        monthlySalary: salary,
        joinDate: localDate(),
        status: 'active',
      });
    } else if (typeof editingStaff === 'number') {
      updateStaffMember(editingStaff, {
        name: sf.name.trim(),
        role: sf.role,
        roleTitleAr: sf.roleTitleAr.trim(),
        phone: sf.phone.trim(),
        nationalId: sf.nationalId.trim(),
        monthlySalary: salary,
        status: sf.status,
      });
    }
    setEditingStaff(null);
  };
  const resign = (s: StaffMember) => {
    if (!confirm(`تأكيد مغادرة الموظف «${s.name}»؟ سيُحفظ سجله ولن يظهر في قائمة العاملين.`)) return;
    updateStaffMember(s.id, { status: 'resigned', leaveDate: localDate() });
  };
  const reinstate = (s: StaffMember) => updateStaffMember(s.id, { status: 'active', leaveDate: undefined });

  const visible = staffMembers.filter((s) => (showResigned ? s.status === 'resigned' : s.status !== 'resigned'));

  const profileCard = (kind: 'admin' | 'reception', title: string) => {
    const u = systemProfiles[kind];
    const isEditing = editingProfile === kind;
    return (
      <div className="border border-slate-200 dark:border-slate-800 rounded-2xl p-3 space-y-2">
        <div className="flex items-center justify-between gap-2">
          <div className="min-w-0">
            <div className="text-[11px] text-sky-600 dark:text-sky-400 font-bold">{title}</div>
            <div className="font-bold text-slate-800 dark:text-slate-100 truncate">{u.name}</div>
            <div className="text-[11px] text-slate-500 truncate">{u.phone || 'لا يوجد رقم'} {u.email ? `• ${u.email}` : ''}</div>
          </div>
          {!isEditing && (
            <button onClick={() => startEditProfile(kind)} className="shrink-0 flex items-center gap-1 px-3 py-1.5 rounded-lg bg-sky-50 dark:bg-sky-950/40 text-sky-700 dark:text-sky-300 text-xs font-semibold cursor-pointer">
              <Pencil className="w-3.5 h-3.5" /> تعديل
            </button>
          )}
        </div>
        {isEditing && (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
            <div><label className={labelCls}>الاسم</label><input className={inputCls} value={pf.name} onChange={(e) => setPf({ ...pf, name: e.target.value })} /></div>
            <div><label className={labelCls}>المسمى الوظيفي</label><input className={inputCls} value={pf.roleAr} onChange={(e) => setPf({ ...pf, roleAr: e.target.value })} /></div>
            <div><label className={labelCls}>الهاتف</label><input className={inputCls} inputMode="tel" value={pf.phone} onChange={(e) => setPf({ ...pf, phone: e.target.value })} /></div>
            <div><label className={labelCls}>البريد الإلكتروني</label><input className={inputCls} type="email" value={pf.email} onChange={(e) => setPf({ ...pf, email: e.target.value })} /></div>
            <div className="sm:col-span-2"><label className={labelCls}>الشفت</label><input className={inputCls} value={pf.shift} onChange={(e) => setPf({ ...pf, shift: e.target.value })} /></div>
            <div className="sm:col-span-2 flex gap-2">
              <button onClick={saveProfile} className="flex items-center gap-1 px-4 py-2 rounded-lg bg-emerald-600 text-white text-xs font-bold cursor-pointer"><Save className="w-3.5 h-3.5" /> حفظ</button>
              <button onClick={() => setEditingProfile(null)} className="px-4 py-2 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 text-xs font-semibold cursor-pointer">إلغاء</button>
            </div>
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="space-y-5 text-xs sm:text-sm">
      <section className="space-y-2">
        <h4 className="font-bold text-slate-800 dark:text-slate-100 flex items-center gap-1.5"><UserCog className="w-4 h-4 text-sky-500" /> حسابات النظام</h4>
        {profileCard('admin', 'المدير العام للنظام')}
        {profileCard('reception', 'حساب الاستقبال')}
      </section>

      <section className="space-y-2">
        <div className="flex items-center justify-between gap-2">
          <h4 className="font-bold text-slate-800 dark:text-slate-100">كادر الفندق ({visible.length})</h4>
          <div className="flex gap-1.5">
            <button onClick={() => setShowResigned((v) => !v)} className="px-2.5 py-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 text-[11px] font-semibold cursor-pointer">
              {showResigned ? 'عرض العاملين' : 'المغادرون'}
            </button>
            <button onClick={startNewStaff} className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-emerald-600 text-white text-[11px] font-bold cursor-pointer">
              <UserPlus className="w-3.5 h-3.5" /> موظف جديد
            </button>
          </div>
        </div>

        {editingStaff !== null && (
          <div className="border border-sky-300 dark:border-sky-800 rounded-2xl p-3 grid grid-cols-1 sm:grid-cols-2 gap-2 bg-sky-50/40 dark:bg-sky-950/20">
            <div><label className={labelCls}>اسم الموظف</label><input className={inputCls} value={sf.name} onChange={(e) => setSf({ ...sf, name: e.target.value })} /></div>
            <div>
              <label className={labelCls}>الوظيفة</label>
              <select className={inputCls} value={sf.role} onChange={(e) => setSf({ ...sf, role: e.target.value as StaffRole, roleTitleAr: ROLE_OPTIONS.find((r) => r.value === e.target.value)?.label || sf.roleTitleAr })}>
                {ROLE_OPTIONS.map((r) => <option key={r.value} value={r.value}>{r.label}</option>)}
              </select>
            </div>
            <div><label className={labelCls}>المسمى (يظهر في السندات)</label><input className={inputCls} value={sf.roleTitleAr} onChange={(e) => setSf({ ...sf, roleTitleAr: e.target.value })} /></div>
            <div><label className={labelCls}>الهاتف</label><input className={inputCls} inputMode="tel" value={sf.phone} onChange={(e) => setSf({ ...sf, phone: e.target.value })} /></div>
            <div><label className={labelCls}>رقم الهوية</label><input className={inputCls} value={sf.nationalId} onChange={(e) => setSf({ ...sf, nationalId: e.target.value })} /></div>
            <div><label className={labelCls}>الراتب الشهري</label><input className={inputCls} type="number" min={0} value={sf.monthlySalary} onChange={(e) => setSf({ ...sf, monthlySalary: Number(e.target.value) })} /></div>
            {editingStaff !== 'new' && (
              <div>
                <label className={labelCls}>الحالة</label>
                <select className={inputCls} value={sf.status} onChange={(e) => setSf({ ...sf, status: e.target.value as StaffMember['status'] })}>
                  <option value="active">على رأس العمل</option>
                  <option value="on_leave">في إجازة</option>
                </select>
              </div>
            )}
            <div className="sm:col-span-2 flex gap-2">
              <button onClick={saveStaff} className="flex items-center gap-1 px-4 py-2 rounded-lg bg-emerald-600 text-white text-xs font-bold cursor-pointer"><Save className="w-3.5 h-3.5" /> حفظ</button>
              <button onClick={() => setEditingStaff(null)} className="flex items-center gap-1 px-4 py-2 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 text-xs font-semibold cursor-pointer"><X className="w-3.5 h-3.5" /> إلغاء</button>
            </div>
          </div>
        )}

        {visible.length === 0 && <p className="text-center text-slate-400 py-4">{showResigned ? 'لا يوجد موظفون مغادرون' : 'لا يوجد موظفون'}</p>}

        {visible.map((s) => (
          <div key={s.id} className="border border-slate-200 dark:border-slate-800 rounded-2xl p-3 flex items-center justify-between gap-2">
            <div className="min-w-0">
              <div className="font-bold text-slate-800 dark:text-slate-100 truncate">{s.name}</div>
              <div className="text-[11px] text-slate-500 truncate">
                {s.roleTitleAr}{s.phone ? ` • ${s.phone}` : ''}
                {s.status === 'on_leave' ? ' • في إجازة' : ''}
                {s.status === 'resigned' && s.leaveDate ? ` • غادر في ${s.leaveDate}` : ''}
              </div>
            </div>
            <div className="flex gap-1.5 shrink-0">
              {s.status !== 'resigned' ? (
                <>
                  <button onClick={() => startEditStaff(s)} className="p-2 rounded-lg bg-sky-50 dark:bg-sky-950/40 text-sky-700 dark:text-sky-300 cursor-pointer" aria-label="تعديل"><Pencil className="w-4 h-4" /></button>
                  <button onClick={() => resign(s)} className="p-2 rounded-lg bg-rose-50 dark:bg-rose-950/40 text-rose-600 cursor-pointer" aria-label="مغادرة موظف"><UserMinus className="w-4 h-4" /></button>
                </>
              ) : (
                <button onClick={() => reinstate(s)} className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 text-[11px] font-semibold cursor-pointer"><UserCheck className="w-3.5 h-3.5" /> إعادة تفعيل</button>
              )}
            </div>
          </div>
        ))}
      </section>
    </div>
  );
};
