import React, { useRef, useState } from 'react';
import { Camera, X, Image as ImageIcon } from 'lucide-react';
import { fileToCompressedDataUrl } from '../utils/image';

interface Props {
  label: string;
  value?: string;
  onChange: (dataUrl: string | undefined) => void;
  round?: boolean;
  maxSide?: number;
}

/** Camera / gallery picker with preview. Images are compressed before being stored. */
export const ImagePicker: React.FC<Props> = ({ label, value, onChange, round, maxSide }) => {
  const ref = useRef<HTMLInputElement>(null);
  const [busy, setBusy] = useState(false);

  const pick = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    setBusy(true);
    try {
      onChange(await fileToCompressedDataUrl(file, maxSide ?? 520));
    } catch {
      alert('تعذّر قراءة الصورة، جرّب صورة أخرى.');
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="flex flex-col items-center gap-1.5">
      <div
        className={`relative w-24 h-24 ${round ? 'rounded-full' : 'rounded-xl'} overflow-hidden border-2 border-dashed border-slate-300 dark:border-slate-600 bg-slate-50 dark:bg-slate-800 flex items-center justify-center`}
      >
        {value ? (
          <img src={value} alt={label} className="w-full h-full object-cover" />
        ) : (
          <ImageIcon className="w-7 h-7 text-slate-300" />
        )}
        {value && (
          <button
            type="button"
            onClick={() => onChange(undefined)}
            className="absolute top-0.5 left-0.5 bg-black/60 text-white rounded-full p-0.5 cursor-pointer"
            aria-label="حذف الصورة"
          >
            <X className="w-3 h-3" />
          </button>
        )}
      </div>
      <button
        type="button"
        onClick={() => ref.current?.click()}
        disabled={busy}
        className="flex items-center gap-1 text-[11px] font-semibold text-sky-600 dark:text-sky-400 cursor-pointer disabled:opacity-50"
      >
        <Camera className="w-3.5 h-3.5" />
        {busy ? 'جارٍ المعالجة…' : label}
      </button>
      <input ref={ref} type="file" accept="image/*" className="hidden" onChange={pick} />
    </div>
  );
};
