import React, { useState, useEffect } from 'react';
import { useHotel } from '../context/HotelContext';
import { Room, Guest, PaymentMethod } from '../types/hotel';
import {
  X,
  User,
  Phone,
  CreditCard,
  Calendar,
  Sparkles,
  CheckCircle,
  Building,
  Shield,
  FileText,
  BadgePercent,
  Coins,
} from 'lucide-react';

export const BookingModal: React.FC = () => {
  const {
    isCheckInModalOpen,
    setIsCheckInModalOpen,
    selectedRoom,
    rooms,
    guests,
    settings,
    checkIn,
    getGuestByPhone,
    setSelectedRoom,
  } = useHotel();

  // Form State
  const [targetRoomId, setTargetRoomId] = useState<number>(0);
  const [guestPhone, setGuestPhone] = useState<string>('');
  const [guestName, setGuestName] = useState<string>('');
  const [guestNationalId, setGuestNationalId] = useState<string>('');
  const [nationality, setNationality] = useState<string>('يمني');
  const [nights, setNights] = useState<number>(1);
  const [discountPercent, setDiscountPercent] = useState<number>(0);
  const [paidAmount, setPaidAmount] = useState<number>(0);
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('card');
  const [notes, setNotes] = useState<string>('');

  const [existingGuest, setExistingGuest] = useState<Guest | null>(null);

  // Available rooms for selection
  const availableRooms = rooms.filter((r) => r.status === 'available');

  useEffect(() => {
    if (selectedRoom && selectedRoom.status === 'available') {
      setTargetRoomId(selectedRoom.id);
    } else if (availableRooms.length > 0) {
      setTargetRoomId(availableRooms[0].id);
    }
  }, [selectedRoom, isCheckInModalOpen]);

  const activeRoom = rooms.find((r) => r.id === targetRoomId);

  // Calculate pricing
  const basePricePerNight = activeRoom ? activeRoom.pricePerNight : 200;
  const rawTotal = basePricePerNight * nights;
  const discountAmount = Math.round((rawTotal * discountPercent) / 100);
  const finalTotal = rawTotal - discountAmount;

  // Auto-fill paid amount when total changes if user wants full pay
  useEffect(() => {
    setPaidAmount(finalTotal);
  }, [finalTotal]);

  // Phone lookup handler
  const handlePhoneChange = (phoneVal: string) => {
    setGuestPhone(phoneVal);
    if (phoneVal.length >= 7) {
      const found = getGuestByPhone(phoneVal);
      if (found) {
        setExistingGuest(found);
        setGuestName(found.name);
        setGuestNationalId(found.nationalId);
        setNationality(found.nationality || 'يمني');
        if (found.isFrequent) {
          setDiscountPercent(found.loyaltyDiscountPercent || settings.defaultLoyaltyDiscount);
        }
      } else {
        setExistingGuest(null);
      }
    } else {
      setExistingGuest(null);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!targetRoomId || !guestName.trim() || !guestPhone.trim()) {
      return;
    }

    const success = await checkIn({
      roomId: targetRoomId,
      guestName: guestName.trim(),
      guestPhone: guestPhone.trim(),
      guestNationalId: guestNationalId.trim(),
      nationality: nationality.trim() || 'يمني',
      nights: Number(nights) || 1,
      pricePerNight: basePricePerNight,
      discountPercent: Number(discountPercent) || 0,
      paidAmount: Number(paidAmount) || 0,
      paymentMethod,
      notes: notes.trim(),
    });

    if (success) {
      setIsCheckInModalOpen(false);
      setSelectedRoom(null);
      // Reset form
      setGuestPhone('');
      setGuestName('');
      setGuestNationalId('');
      setNotes('');
      setExistingGuest(null);
    }
  };

  if (!isCheckInModalOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs animate-fadeIn">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl w-full max-w-2xl max-h-[92vh] overflow-y-auto shadow-2xl flex flex-col">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between bg-slate-50 dark:bg-slate-950/50 sticky top-0 z-10">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-600 text-white flex items-center justify-center font-bold shadow-md shadow-emerald-900/30">
              <Building className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900 dark:text-white">
                تسجيل دخول وحجز فندقي جديد (Check-in)
              </h2>
              <p className="text-xs text-slate-500">إدخال بيانات النزيل وتسكين الغرفة في قاعدة بيانات SQLite</p>
            </div>
          </div>

          <button
            onClick={() => setIsCheckInModalOpen(false)}
            className="p-2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-5 space-y-4 text-xs">
          {/* Room Selection */}
          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
              اختر الغرفة المراد حجزها:
            </label>
            {availableRooms.length === 0 ? (
              <div className="p-3 bg-rose-50 dark:bg-rose-950/30 border border-rose-200 dark:border-rose-900 rounded-xl text-rose-700 dark:text-rose-300 text-xs">
                ⚠️ لا توجد غرف متاحة حالياً. جميع الغرف إما مشغولة أو قيد التنظيف.
              </div>
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2">
                {availableRooms.map((r) => (
                  <button
                    key={r.id}
                    type="button"
                    onClick={() => setTargetRoomId(r.id)}
                    className={`p-2.5 rounded-xl border text-right transition cursor-pointer flex flex-col justify-between ${
                      targetRoomId === r.id
                        ? 'bg-emerald-600 text-white border-emerald-600 shadow-sm'
                        : 'bg-white dark:bg-slate-800/80 border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-200 hover:border-emerald-500'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-sm font-mono">#{r.roomNumber}</span>
                      <span className={`text-[10px] ${targetRoomId === r.id ? 'text-emerald-100' : 'text-slate-400'}`}>
                        ط {r.floor}
                      </span>
                    </div>
                    <div className="text-[11px] mt-1 opacity-90 truncate">
                      {r.type === 'single'
                        ? 'مفردة'
                        : r.type === 'double'
                        ? 'مزدوجة'
                        : r.type === 'suite'
                        ? 'جناح'
                        : 'VIP'}
                    </div>
                    <div className="text-xs font-bold mt-1">
                      {r.pricePerNight} {settings.currencySymbol}
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Guest Search and Autofill Section */}
          <div className="p-4 bg-slate-50 dark:bg-slate-800/40 rounded-xl border border-slate-200 dark:border-slate-700/60 space-y-3">
            <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-700/60 pb-2">
              <span className="font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
                <User className="w-4 h-4 text-emerald-600" />
                بيانات النزيل (Guest Information)
              </span>
              <span className="text-[11px] text-slate-500">
                (البحث التلقائي عن العملاء الدائمين برقم الهاتف)
              </span>
            </div>

            {/* Phone & Name Row */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-slate-600 dark:text-slate-400 mb-1">
                  رقم الهاتف (مفتاح البحث): <span className="text-rose-500">*</span>
                </label>
                <div className="relative">
                  <input
                    type="tel"
                    placeholder="مثال: 0501234567"
                    value={guestPhone}
                    onChange={(e) => handlePhoneChange(e.target.value)}
                    required
                    className="w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg pl-3 pr-8 py-2 text-slate-900 dark:text-white focus:outline-none focus:border-emerald-500"
                  />
                  <Phone className="w-4 h-4 text-slate-400 absolute right-2.5 top-2.5" />
                </div>
              </div>

              <div>
                <label className="block text-slate-600 dark:text-slate-400 mb-1">
                  اسم العميل الكامل: <span className="text-rose-500">*</span>
                </label>
                <div className="relative">
                  <input
                    type="text"
                    placeholder="الاسم الثلاثي أو الثنائي"
                    value={guestName}
                    onChange={(e) => setGuestName(e.target.value)}
                    required
                    className="w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg pl-3 pr-8 py-2 text-slate-900 dark:text-white focus:outline-none focus:border-emerald-500"
                  />
                  <User className="w-4 h-4 text-slate-400 absolute right-2.5 top-2.5" />
                </div>
              </div>
            </div>

            {/* National ID & Nationality */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-slate-600 dark:text-slate-400 mb-1">
                  رقم الهوية الوطنية / جواز السفر / الإقامة:
                </label>
                <div className="relative">
                  <input
                    type="text"
                    placeholder="رقم الإثبات أو الهوية"
                    value={guestNationalId}
                    onChange={(e) => setGuestNationalId(e.target.value)}
                    className="w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg pl-3 pr-8 py-2 text-slate-900 dark:text-white focus:outline-none focus:border-emerald-500"
                  />
                  <Shield className="w-4 h-4 text-slate-400 absolute right-2.5 top-2.5" />
                </div>
              </div>

              <div>
                <label className="block text-slate-600 dark:text-slate-400 mb-1">الجنسية:</label>
                <input
                  type="text"
                  placeholder="مثال: يمني، سعودي، مصري..."
                  value={nationality}
                  onChange={(e) => setNationality(e.target.value)}
                  className="w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg px-3 py-2 text-slate-900 dark:text-white focus:outline-none focus:border-emerald-500"
                />
              </div>
            </div>

            {/* Existing Guest Loyalty Notification */}
            {existingGuest && (
              <div className="p-3 bg-amber-500/10 border border-amber-500/30 rounded-xl text-amber-800 dark:text-amber-300 flex items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-amber-500 shrink-0" />
                  <div>
                    <span className="font-bold">عميل سابق مسجل!</span> عدد الزيارات السابقة:{' '}
                    <strong>{existingGuest.visitCount}</strong>
                    {existingGuest.isFrequent && (
                      <span className="mr-1.5 px-1.5 py-0.5 rounded bg-amber-400/30 font-bold text-[10px]">
                        عميل دائم VIP
                      </span>
                    )}
                  </div>
                </div>
                <span className="text-[11px] text-amber-600 dark:text-amber-400 font-semibold">
                  خصم الولاء المطبق: {discountPercent}%
                </span>
              </div>
            )}
          </div>

          {/* Stay Duration & Pricing Details */}
          <div className="p-4 bg-slate-50 dark:bg-slate-800/40 rounded-xl border border-slate-200 dark:border-slate-700/60 space-y-3">
            <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-700/60 pb-2">
              <span className="font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
                <Calendar className="w-4 h-4 text-emerald-600" />
                مدة الإقامة والتسعير (Stay & Pricing)
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-slate-600 dark:text-slate-400 mb-1">
                  عدد الليالي (Nights):
                </label>
                <input
                  type="number"
                  min="1"
                  max="60"
                  value={nights}
                  onChange={(e) => setNights(Math.max(1, parseInt(e.target.value, 10) || 1))}
                  required
                  className="w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg px-3 py-2 text-slate-900 dark:text-white font-mono text-center font-bold focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block text-slate-600 dark:text-slate-400 mb-1">
                  سعر الليلة (ر.ي):
                </label>
                <input
                  type="text"
                  disabled
                  value={`${basePricePerNight} ${settings.currencySymbol}`}
                  className="w-full bg-slate-100 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg px-3 py-2 text-slate-500 font-mono text-center"
                />
              </div>

              <div>
                <label className="block text-slate-600 dark:text-slate-400 mb-1">
                  نسبة الخصم (%):
                </label>
                <div className="relative">
                  <input
                    type="number"
                    min="0"
                    max="100"
                    value={discountPercent}
                    onChange={(e) => setDiscountPercent(Math.min(100, Math.max(0, parseInt(e.target.value, 10) || 0)))}
                    className="w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg pl-3 pr-8 py-2 text-slate-900 dark:text-white font-mono text-center font-bold focus:outline-none focus:border-emerald-500"
                  />
                  <BadgePercent className="w-4 h-4 text-slate-400 absolute right-2.5 top-2.5" />
                </div>
              </div>
            </div>

            {/* Payment Row */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 border-t border-slate-200 dark:border-slate-700/60">
              <div>
                <label className="block text-slate-600 dark:text-slate-400 mb-1">طريقة الدفع:</label>
                <select
                  value={paymentMethod}
                  onChange={(e) => setPaymentMethod(e.target.value as PaymentMethod)}
                  className="w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg px-3 py-2 text-slate-900 dark:text-white focus:outline-none focus:border-emerald-500"
                >
                  <option value="card">💳 بطاقة بنكية / مدى / Visa</option>
                  <option value="cash">💵 نقداً (Cash)</option>
                  <option value="transfer">🏦 تحويل بنكي</option>
                  <option value="unpaid">⏳ الدفع لاحقاً عند المغادرة</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-600 dark:text-slate-400 mb-1">
                  المبلغ المدفوع الآن (ر.ي):
                </label>
                <input
                  type="number"
                  min="0"
                  max={finalTotal}
                  value={paidAmount}
                  onChange={(e) => setPaidAmount(parseFloat(e.target.value) || 0)}
                  className="w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg px-3 py-2 text-slate-900 dark:text-white font-mono text-center font-bold focus:outline-none focus:border-emerald-500"
                />
              </div>
            </div>

            {/* Total Price Summary Box */}
            <div className="p-3 bg-emerald-50 dark:bg-emerald-950/40 rounded-xl border border-emerald-200 dark:border-emerald-900 flex items-center justify-between">
              <div>
                <span className="text-slate-500 dark:text-slate-400 text-xs block">إجمالي قيمة الحجز الصافية:</span>
                <span className="text-xs text-slate-400">
                  {nights} ليالي × {basePricePerNight} {settings.currencySymbol}
                  {discountPercent > 0 && ` (خصم ${discountPercent}%)`}
                </span>
              </div>
              <div className="text-right">
                <span className="text-xl font-black text-emerald-600 dark:text-emerald-400 font-mono">
                  {finalTotal} {settings.currencySymbol}
                </span>
                {paidAmount < finalTotal && (
                  <span className="block text-[11px] text-rose-500">
                    متبقي للدفع: {finalTotal - paidAmount} {settings.currencySymbol}
                  </span>
                )}
              </div>
            </div>
          </div>

          {/* Notes */}
          <div>
            <label className="block text-slate-600 dark:text-slate-400 mb-1">ملاحظات أو طلبات خاصة:</label>
            <input
              type="text"
              placeholder="مثال: سرير إضافي، تسجيل خروج متأخر، ضيف هادئ..."
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg px-3 py-2 text-slate-900 dark:text-white focus:outline-none focus:border-emerald-500"
            />
          </div>

          {/* Footer Actions */}
          <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-200 dark:border-slate-800">
            <button
              type="button"
              onClick={() => setIsCheckInModalOpen(false)}
              className="px-4 py-2.5 rounded-xl text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 font-medium transition cursor-pointer"
            >
              إلغاء
            </button>
            <button
              type="submit"
              disabled={availableRooms.length === 0}
              className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white font-bold rounded-xl transition cursor-pointer flex items-center gap-2 shadow-md shadow-emerald-900/30"
            >
              <CheckCircle className="w-4 h-4" />
              <span>تأكيد الحجز وتسكين الغرفة</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
