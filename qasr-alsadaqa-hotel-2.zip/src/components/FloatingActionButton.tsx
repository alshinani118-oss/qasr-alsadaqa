import React, { useState } from 'react';
import { useHotel } from '../context/HotelContext';
import {
  Plus,
  Calendar,
  UtensilsCrossed,
  DoorOpen,
  ArrowLeftRight,
  X,
} from 'lucide-react';

export const FloatingActionButton: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const {
    setIsCheckInModalOpen,
    setIsAddRoomModalOpen,
    setIsNewRoomServiceModalOpen,
    setIsNewExpenseModalOpen,
  } = useHotel();

  return (
    <div className="fixed bottom-6 left-6 z-40 flex flex-col items-start gap-3 select-none" dir="rtl">
      {/* Floating Speed Dial Actions */}
      {isOpen && (
        <div className="flex flex-col items-start gap-2.5 mb-1 animate-scaleUp">
          {/* Quick Expense */}
          <button
            onClick={() => {
              setIsOpen(false);
              setIsNewExpenseModalOpen(true);
            }}
            className="flex items-center gap-2.5 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-100 px-3.5 py-2 rounded-2xl shadow-lg border border-slate-200 dark:border-slate-700 text-xs font-bold hover:bg-slate-50 transition cursor-pointer"
          >
            <div className="w-7 h-7 rounded-xl bg-rose-500/10 text-rose-500 flex items-center justify-center">
              <ArrowLeftRight className="w-4 h-4" />
            </div>
            <span>سند مصروف جديد</span>
          </button>

          {/* Quick Room Service */}
          <button
            onClick={() => {
              setIsOpen(false);
              setIsNewRoomServiceModalOpen(true);
            }}
            className="flex items-center gap-2.5 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-100 px-3.5 py-2 rounded-2xl shadow-lg border border-slate-200 dark:border-slate-700 text-xs font-bold hover:bg-slate-50 transition cursor-pointer"
          >
            <div className="w-7 h-7 rounded-xl bg-amber-500/10 text-amber-500 flex items-center justify-center">
              <UtensilsCrossed className="w-4 h-4" />
            </div>
            <span>طلب خدمة غرف</span>
          </button>

          {/* Quick Room */}
          <button
            onClick={() => {
              setIsOpen(false);
              setIsAddRoomModalOpen(true);
            }}
            className="flex items-center gap-2.5 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-100 px-3.5 py-2 rounded-2xl shadow-lg border border-slate-200 dark:border-slate-700 text-xs font-bold hover:bg-slate-50 transition cursor-pointer"
          >
            <div className="w-7 h-7 rounded-xl bg-emerald-500/10 text-emerald-500 flex items-center justify-center">
              <DoorOpen className="w-4 h-4" />
            </div>
            <span>إضافة غرفة جديدة</span>
          </button>

          {/* Quick Check-in */}
          <button
            onClick={() => {
              setIsOpen(false);
              setIsCheckInModalOpen(true);
            }}
            className="flex items-center gap-2.5 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-100 px-3.5 py-2 rounded-2xl shadow-lg border border-slate-200 dark:border-slate-700 text-xs font-bold hover:bg-slate-50 transition cursor-pointer"
          >
            <div className="w-7 h-7 rounded-xl bg-sky-500/10 text-sky-500 flex items-center justify-center">
              <Calendar className="w-4 h-4" />
            </div>
            <span>حجز وتسكين نزيل</span>
          </button>
        </div>
      )}

      {/* Main Floating Button (Sky Blue Circular Button with +) */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        title="إجراء سريع"
        className="w-14 h-14 rounded-2xl bg-sky-600 hover:bg-sky-500 active:scale-95 text-white shadow-xl flex items-center justify-center transition-all cursor-pointer border border-sky-400/40"
        aria-label="إجراء سريع"
      >
        {isOpen ? (
          <X className="w-6 h-6 stroke-[2.5]" />
        ) : (
          <Plus className="w-7 h-7 stroke-[2.5]" />
        )}
      </button>
    </div>
  );
};
