import React, { useState } from 'react';
import { useHotel } from '../context/HotelContext';
import { verifyPin, hasPin } from '../utils/pin';
import { Power, Lock, RotateCcw, X, KeyRound, CheckCircle2, User } from 'lucide-react';

export const LogoutModal: React.FC = () => {
  const {
    isLogoutModalOpen,
    setIsLogoutModalOpen,
    currentUser,
    isLocked,
    setIsLocked,
    settings,
  } = useHotel();

  const [unlockPin, setUnlockPin] = useState('');
  const [pinError, setPinError] = useState(false);
  const [failedAttempts, setFailedAttempts] = useState(0);
  const [lockedUntil, setLockedUntil] = useState(0);

  const tryUnlock = async () => {
    if (Date.now() < lockedUntil) return;
    const ok = await verifyPin(unlockPin);
    if (ok) {
      setIsLocked(false);
      setUnlockPin('');
      setFailedAttempts(0);
      setPinError(false);
      return;
    }
    const attempts = failedAttempts + 1;
    setFailedAttempts(attempts);
    setPinError(true);
    setUnlockPin('');
    // 5 wrong tries -> 30 second cool-down
    if (attempts % 5 === 0) setLockedUntil(Date.now() + 30000);
  };

  if (!isLogoutModalOpen && !isLocked) return null;

  // Lock Screen View
  if (isLocked) {
    return (
      <div
        className="fixed inset-0 z-50 bg-slate-900/95 backdrop-blur-md flex flex-col items-center justify-center p-4 select-none"
        dir="rtl"
      >
        <div className="bg-white dark:bg-slate-900 rounded-3xl p-8 w-full max-w-sm border border-slate-200 dark:border-slate-800 shadow-2xl text-center space-y-6 animate-scaleUp">
          <div className="w-16 h-16 rounded-full bg-rose-500/10 text-rose-500 flex items-center justify-center mx-auto">
            <Lock className="w-8 h-8 stroke-[2]" />
          </div>

          <div>
            <h3 className="text-xl font-bold text-slate-800 dark:text-slate-100">
              الشاشة مقفلة (Screen Locked)
            </h3>
            <p className="text-xs text-slate-400 mt-1">
              {hasPin()
                ? `مرحباً ${currentUser.name}، أدخل رمز PIN لإلغاء القفل`
                : `مرحباً ${currentUser.name}، لم يتم تعيين رمز PIN بعد — اضغط للمتابعة`}
            </p>
          </div>

          <div>
            <input
              type="password"
              maxLength={4}
              placeholder="••••"
              value={unlockPin}
              inputMode="numeric"
              onChange={(e) => {
                setUnlockPin(e.target.value.replace(/\D/g, ''));
                setPinError(false);
              }}
              onKeyDown={(e) => {
                if (e.key === 'Enter') tryUnlock();
              }}
              className="w-40 mx-auto text-center text-2xl tracking-widest font-mono bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl p-3 font-bold"
            />
            {pinError && (
              <p className="text-xs text-rose-500 mt-1 font-semibold">رمز PIN غير صحيح{failedAttempts > 0 && failedAttempts % 5 === 0 ? ' — انتظر 30 ثانية' : ''}</p>
            )}
          </div>

          <button
            onClick={tryUnlock}
            className="w-full py-3 rounded-2xl bg-sky-600 hover:bg-sky-500 text-white font-bold text-sm shadow-md transition cursor-pointer active:scale-95"
          >
            إلغاء القفل والمتابعة
          </button>
        </div>
      </div>
    );
  }

  // Logout Confirmation Modal
  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4" dir="rtl">
      <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 w-full max-w-sm border border-slate-200 dark:border-slate-800 shadow-2xl space-y-5 animate-scaleUp text-center">
        {/* Soft Red Icon matching screenshot */}
        <div className="w-16 h-16 rounded-3xl bg-rose-50 dark:bg-rose-950/50 text-rose-500 flex items-center justify-center mx-auto border border-rose-100 dark:border-rose-900/40">
          <Power className="w-8 h-8 stroke-[2]" />
        </div>

        <div>
          <h3 className="text-lg font-bold text-slate-800 dark:text-slate-100">
            تسجيل الخروج أو قفل الشاشة
          </h3>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1.5 leading-relaxed">
            المستخدم الحالي: <strong>{currentUser.name}</strong> (@{currentUser.username})
            <br />
            هل تود قفل الشاشة مؤقتاً لتسليم الشفت أو إنهاء الجلسة؟
          </p>
        </div>

        <div className="space-y-2 pt-1">
          {/* Lock Screen */}
          <button
            onClick={() => {
              setIsLogoutModalOpen(false);
              setIsLocked(true);
            }}
            className="w-full py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-semibold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-sm transition cursor-pointer"
          >
            <Lock className="w-4 h-4" />
            <span>قفل الشاشة مؤقتاً (Lock Screen)</span>
          </button>

          {/* Confirm Logout */}
          <button
            onClick={() => {
              setIsLogoutModalOpen(false);
              setIsLocked(true);
            }}
            className="w-full py-3 rounded-xl bg-rose-50 hover:bg-rose-100 dark:bg-rose-950/40 text-rose-600 dark:text-rose-400 font-semibold text-xs sm:text-sm flex items-center justify-center gap-2 border border-rose-100 dark:border-rose-900/50 transition cursor-pointer"
          >
            <Power className="w-4 h-4 text-rose-500" />
            <span>تسجيل الخروج وتسليم العهدة</span>
          </button>

          {/* Cancel */}
          <button
            onClick={() => setIsLogoutModalOpen(false)}
            className="w-full py-2.5 rounded-xl text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 text-xs font-medium transition cursor-pointer"
          >
            إلغاء والعودة
          </button>
        </div>
      </div>
    </div>
  );
};
