import React from 'react';
import { useHotel } from '../context/HotelContext';
import { Room, RoomStatus, RoomType } from '../types/hotel';
import {
  User,
  Clock,
  Sparkles,
  CheckCircle2,
  Calendar,
  Layers,
  SlidersHorizontal,
  Plus,
  AlertCircle,
  Wrench,
  ShieldCheck,
  Phone,
  ArrowLeftRight,
} from 'lucide-react';

export const RoomGrid: React.FC = () => {
  const {
    rooms,
    guests,
    statusFilter,
    setStatusFilter,
    floorFilter,
    setFloorFilter,
    searchQuery,
    setSelectedRoom,
    setIsCheckInModalOpen,
    completeHousekeeping,
    settings,
    setIsAddRoomModalOpen,
    setIsLinkGuestModalOpen,
  } = useHotel();

  // Distinct floors
  const floors = (Array.from(new Set(rooms.map((r) => r.floor))) as number[]).sort((a, b) => a - b);

  // Filtered rooms
  const filteredRooms = rooms.filter((room) => {
    // Status Filter
    if (statusFilter !== 'all' && room.status !== statusFilter) {
      return false;
    }
    // Floor Filter
    if (floorFilter !== null && room.floor !== floorFilter) {
      return false;
    }
    // Search Query
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      const matchRoom = room.roomNumber.toLowerCase().includes(q);
      const matchGuest = (room.currentGuestName || '').toLowerCase().includes(q);
      const matchType = room.type.toLowerCase().includes(q);
      if (!matchRoom && !matchGuest && !matchType) return false;
    }
    return true;
  });

  const getStatusBadge = (status: RoomStatus) => {
    switch (status) {
      case 'available':
        return {
          bg: 'bg-emerald-500/10 text-emerald-600 border-emerald-500/30',
          dot: 'bg-emerald-500',
          label: 'متاحة للحجز',
          cardBorder: 'hover:border-emerald-500 border-slate-200 dark:border-slate-800',
          accentBg: 'bg-emerald-500',
        };
      case 'occupied':
        return {
          bg: 'bg-rose-500/10 text-rose-600 border-rose-500/30',
          dot: 'bg-rose-500',
          label: 'مشغولة (نزيل)',
          cardBorder: 'border-rose-300 dark:border-rose-900/50 hover:border-rose-500',
          accentBg: 'bg-rose-500',
        };
      case 'cleaning':
        return {
          bg: 'bg-amber-500/10 text-amber-600 border-amber-500/30',
          dot: 'bg-amber-500',
          label: 'تحت التنظيف',
          cardBorder: 'border-amber-300 dark:border-amber-900/50 hover:border-amber-500',
          accentBg: 'bg-amber-500',
        };
      case 'maintenance':
        return {
          bg: 'bg-purple-500/10 text-purple-600 border-purple-500/30',
          dot: 'bg-purple-500',
          label: 'صيانة وتجهيز',
          cardBorder: 'border-purple-300 dark:border-purple-900/50 hover:border-purple-500',
          accentBg: 'bg-purple-500',
        };
    }
  };

  const getRoomTypeLabel = (type: RoomType) => {
    switch (type) {
      case 'single':
        return 'مفردة (Single)';
      case 'double':
        return 'مزدوجة (Double)';
      case 'triple':
        return 'ثلاثية (Triple)';
      case 'suite':
        return 'جناح عائلي (Suite)';
      case 'vip_deluxe':
        return 'جناح ملكي فاخر (VIP)';
    }
  };

  return (
    <div className="space-y-4">
      {/* Filters Toolbar */}
      <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        {/* Status Filter Chips */}
        <div className="flex items-center gap-1.5 flex-wrap">
          <button
            onClick={() => setStatusFilter('all')}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition cursor-pointer ${
              statusFilter === 'all'
                ? 'bg-slate-900 text-white dark:bg-slate-100 dark:text-slate-900 shadow-sm'
                : 'bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-300 hover:bg-slate-200'
            }`}
          >
            الكل ({rooms.length})
          </button>

          <button
            onClick={() => setStatusFilter('available')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition cursor-pointer border ${
              statusFilter === 'available'
                ? 'bg-emerald-600 text-white border-emerald-600 shadow-sm'
                : 'bg-emerald-500/10 text-emerald-600 border-emerald-500/20 hover:bg-emerald-500/20'
            }`}
          >
            <span className="w-2 h-2 rounded-full bg-emerald-500 shrink-0"></span>
            <span>متاحة ({rooms.filter((r) => r.status === 'available').length})</span>
          </button>

          <button
            onClick={() => setStatusFilter('occupied')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition cursor-pointer border ${
              statusFilter === 'occupied'
                ? 'bg-rose-600 text-white border-rose-600 shadow-sm'
                : 'bg-rose-500/10 text-rose-600 border-rose-500/20 hover:bg-rose-500/20'
            }`}
          >
            <span className="w-2 h-2 rounded-full bg-rose-500 shrink-0"></span>
            <span>مشغولة ({rooms.filter((r) => r.status === 'occupied').length})</span>
          </button>

          <button
            onClick={() => setStatusFilter('cleaning')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition cursor-pointer border ${
              statusFilter === 'cleaning'
                ? 'bg-amber-600 text-white border-amber-600 shadow-sm'
                : 'bg-amber-500/10 text-amber-600 border-amber-500/20 hover:bg-amber-500/20'
            }`}
          >
            <span className="w-2 h-2 rounded-full bg-amber-500 shrink-0"></span>
            <span>تنظيف ({rooms.filter((r) => r.status === 'cleaning').length})</span>
          </button>

          <button
            onClick={() => setStatusFilter('maintenance')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition cursor-pointer border ${
              statusFilter === 'maintenance'
                ? 'bg-purple-600 text-white border-purple-600 shadow-sm'
                : 'bg-purple-500/10 text-purple-600 border-purple-500/20 hover:bg-purple-500/20'
            }`}
          >
            <span className="w-2 h-2 rounded-full bg-purple-500 shrink-0"></span>
            <span>صيانة ({rooms.filter((r) => r.status === 'maintenance').length})</span>
          </button>
        </div>

        {/* Floor Selection & Quick Actions */}
        <div className="flex items-center gap-3 flex-wrap">
          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-500 flex items-center gap-1 shrink-0">
              <Layers className="w-3.5 h-3.5" />
              الطابق:
            </span>
            <div className="flex items-center gap-1">
              <button
                onClick={() => setFloorFilter(null)}
                className={`px-2.5 py-1 text-xs rounded-md transition cursor-pointer ${
                  floorFilter === null
                    ? 'bg-slate-800 text-white font-medium'
                    : 'bg-slate-100 dark:bg-slate-800/60 text-slate-600 dark:text-slate-400 hover:bg-slate-200'
                }`}
              >
                الكل
              </button>
              {floors.map((fl) => (
                <button
                  key={fl}
                  onClick={() => setFloorFilter(fl)}
                  className={`px-2.5 py-1 text-xs rounded-md transition cursor-pointer ${
                    floorFilter === fl
                      ? 'bg-emerald-600 text-white font-medium'
                      : 'bg-slate-100 dark:bg-slate-800/60 text-slate-600 dark:text-slate-400 hover:bg-slate-200'
                  }`}
                >
                  الطابق {fl}
                </button>
              ))}
            </div>
          </div>

          <div className="flex items-center gap-1.5 border-r border-slate-200 dark:border-slate-800 pr-3">
            <button
              onClick={() => setIsLinkGuestModalOpen(true)}
              className="px-2.5 py-1.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-lg text-xs font-semibold flex items-center gap-1 transition cursor-pointer"
              title="ربط عميل مسجل بغرفة وتسكينه"
            >
              <ArrowLeftRight className="w-3.5 h-3.5 text-emerald-500" />
              <span className="hidden sm:inline">ربط عميل بغرفة</span>
            </button>

            <button
              onClick={() => setIsAddRoomModalOpen(true)}
              className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold flex items-center gap-1 transition cursor-pointer shadow-xs"
              title="إضافة غرفة جديدة"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>+ إضافة غرفة</span>
            </button>
          </div>
        </div>
      </div>

      {/* Rooms Grid */}
      {filteredRooms.length === 0 ? (
        <div className="bg-white dark:bg-slate-900 border border-dashed border-slate-300 dark:border-slate-800 rounded-xl p-12 text-center">
          <AlertCircle className="w-10 h-10 text-slate-400 mx-auto mb-3" />
          <h3 className="font-semibold text-slate-700 dark:text-slate-200 text-sm">لا توجد غرف مطابقة لهذا الفلتر</h3>
          <p className="text-xs text-slate-500 mt-1">حاول تغيير فلتر البحث أو إزالة الفلاتر المحددة</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {filteredRooms.map((room) => {
            const badge = getStatusBadge(room.status);
            const isGuestVip =
              room.currentGuestPhone &&
              guests.find((g) => g.phone === room.currentGuestPhone || g.name === room.currentGuestName)?.isFrequent;

            return (
              <div
                key={room.id}
                onClick={() => setSelectedRoom(room)}
                className={`group relative bg-white dark:bg-slate-900 rounded-xl border-2 transition-all duration-200 shadow-sm hover:shadow-md cursor-pointer flex flex-col justify-between overflow-hidden ${badge.cardBorder}`}
              >
                {/* Colored Top Header Bar */}
                <div className={`h-2 w-full ${badge.accentBg}`} />

                <div className="p-4 space-y-3">
                  {/* Top Row: Room Number & Type */}
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <div className="flex items-center gap-1.5">
                        <span className="text-xl font-black text-slate-900 dark:text-white tracking-tight">
                          #{room.roomNumber}
                        </span>
                        <span className="text-[11px] text-slate-400 font-mono">ط {room.floor}</span>
                      </div>
                      <p className="text-xs font-medium text-slate-500 dark:text-slate-400">
                        {getRoomTypeLabel(room.type)}
                      </p>
                    </div>

                    <span
                      className={`text-[11px] px-2 py-0.5 rounded-full font-semibold border flex items-center gap-1 shrink-0 ${badge.bg}`}
                    >
                      <span className={`w-1.5 h-1.5 rounded-full ${badge.dot}`}></span>
                      {badge.label}
                    </span>
                  </div>

                  {/* Occupant or Room Detail Card Content */}
                  {room.status === 'occupied' ? (
                    <div className="bg-rose-50 dark:bg-rose-950/30 p-2.5 rounded-lg border border-rose-100 dark:border-rose-900/40 space-y-1.5">
                      <div className="flex items-center justify-between gap-2">
                        <div className="flex items-center gap-1.5 overflow-hidden">
                          <User className="w-3.5 h-3.5 text-rose-600 shrink-0" />
                          <span className="text-xs font-bold text-slate-800 dark:text-slate-200 truncate">
                            {room.currentGuestName || 'نزيل حالي'}
                          </span>
                        </div>
                        {isGuestVip && (
                          <span className="px-1.5 py-0.2 bg-amber-400/20 text-amber-600 dark:text-amber-300 text-[10px] font-bold rounded flex items-center gap-0.5 shrink-0 border border-amber-400/30">
                            <Sparkles className="w-2.5 h-2.5" />
                            دائم VIP
                          </span>
                        )}
                      </div>

                      <div className="flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400">
                        <span className="flex items-center gap-1">
                          <Calendar className="w-3 h-3 text-slate-400" />
                          خروج: {room.checkOutDate || '—'}
                        </span>
                        <span className="font-semibold text-rose-600 dark:text-rose-400">
                          {room.pricePerNight} {settings.currencySymbol} / ليلة
                        </span>
                      </div>
                    </div>
                  ) : room.status === 'cleaning' ? (
                    <div className="bg-amber-50 dark:bg-amber-950/30 p-2.5 rounded-lg border border-amber-100 dark:border-amber-900/40 space-y-2">
                      <p className="text-xs text-amber-800 dark:text-amber-300 flex items-center gap-1.5">
                        <Sparkles className="w-3.5 h-3.5 text-amber-500 shrink-0" />
                        الغرفة بحاجة للهاوس كيبينج والتعقيم
                      </p>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          completeHousekeeping(room.id);
                        }}
                        className="w-full py-1.5 px-3 bg-emerald-600 hover:bg-emerald-500 text-white rounded-md text-xs font-bold transition flex items-center justify-center gap-1.5 shadow-sm"
                      >
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>تم اكتمال التنظيف</span>
                      </button>
                    </div>
                  ) : room.status === 'maintenance' ? (
                    <div className="bg-purple-50 dark:bg-purple-950/30 p-2.5 rounded-lg border border-purple-100 dark:border-purple-900/40">
                      <p className="text-xs text-purple-700 dark:text-purple-300 flex items-center gap-1.5">
                        <Wrench className="w-3.5 h-3.5 text-purple-500 shrink-0" />
                        {room.notes || 'تحت الصيانة الدورية'}
                      </p>
                    </div>
                  ) : (
                    /* Available Room Info */
                    <div className="space-y-2">
                      <div className="flex items-center justify-between text-xs text-slate-600 dark:text-slate-400">
                        <span>السعر لليلة الواحدة:</span>
                        <span className="font-bold text-slate-900 dark:text-white text-sm">
                          {room.pricePerNight} {settings.currencySymbol}
                        </span>
                      </div>
                      <div className="flex flex-wrap gap-1">
                        {room.features.slice(0, 2).map((feat, idx) => (
                          <span
                            key={idx}
                            className="text-[10px] bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 px-2 py-0.5 rounded"
                          >
                            {feat}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                {/* Bottom Card Footer */}
                <div className="px-4 py-2.5 bg-slate-50 dark:bg-slate-950 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs">
                  <span className="text-slate-400 text-[11px]">السعة: {room.capacity} أفراد</span>

                  {room.status === 'available' ? (
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setSelectedRoom(room);
                        setIsCheckInModalOpen(true);
                      }}
                      className="text-emerald-600 dark:text-emerald-400 font-bold hover:underline flex items-center gap-1"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      حجز سريع
                    </button>
                  ) : (
                    <span className="text-slate-500 dark:text-slate-400 font-medium group-hover:text-emerald-500 transition">
                      عرض التفاصيل &larr;
                    </span>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
