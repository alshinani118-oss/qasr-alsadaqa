import React, { useEffect, useState } from 'react';
import { Sun, Moon, MonitorSmartphone } from 'lucide-react';
import { getThemeMode, setThemeMode, ThemeMode } from '../utils/theme';

const ORDER: ThemeMode[] = ['system', 'light', 'dark'];
const LABEL: Record<ThemeMode, string> = { system: 'تلقائي (حسب النظام)', light: 'نهاري', dark: 'ليلي' };

/** Cycles system → day → night. */
export const ThemeToggle: React.FC = () => {
  const [mode, setMode] = useState<ThemeMode>(getThemeMode());

  useEffect(() => {
    const on = (e: Event) => setMode((e as CustomEvent<ThemeMode>).detail);
    window.addEventListener('qasr-theme-change', on);
    return () => window.removeEventListener('qasr-theme-change', on);
  }, []);

  const next = () => setThemeMode(ORDER[(ORDER.indexOf(mode) + 1) % ORDER.length]);
  const Icon = mode === 'light' ? Sun : mode === 'dark' ? Moon : MonitorSmartphone;

  return (
    <button
      type="button"
      onClick={next}
      title={`المظهر: ${LABEL[mode]} — اضغط للتبديل`}
      aria-label={`المظهر: ${LABEL[mode]}`}
      className="p-2 text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-xl border border-slate-700 transition cursor-pointer flex items-center gap-1.5"
    >
      <Icon className="w-4 h-4 text-amber-300" />
      <span className="hidden lg:inline text-xs">{LABEL[mode]}</span>
    </button>
  );
};
