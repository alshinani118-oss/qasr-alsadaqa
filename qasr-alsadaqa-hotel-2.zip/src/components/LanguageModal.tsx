import React, { useState } from 'react';
import { useHotel } from '../context/HotelContext';
import { Globe, Check, X } from 'lucide-react';

export const LanguageModal: React.FC = () => {
  const { isLanguageModalOpen, setIsLanguageModalOpen } = useHotel();
  const [selectedLang, setSelectedLang] = useState<'ar' | 'en'>('ar');

  if (!isLanguageModalOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4" dir="rtl">
      <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 w-full max-w-sm border border-slate-200 dark:border-slate-800 shadow-2xl space-y-5 animate-scaleUp">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-sky-500/10 text-sky-500">
              <Globe className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-800 dark:text-slate-100">
                اختيار لغة النظام (Language)
              </h3>
              <p className="text-xs text-slate-400">تغيير لغة واجهة البرنامج والتقارير</p>
            </div>
          </div>

          <button
            onClick={() => setIsLanguageModalOpen(false)}
            className="p-1 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Languages Options */}
        <div className="space-y-2.5 text-sm">
          <button
            onClick={() => setSelectedLang('ar')}
            className={`w-full p-3.5 rounded-2xl border text-right transition cursor-pointer flex items-center justify-between ${
              selectedLang === 'ar'
                ? 'border-sky-500 bg-sky-50 dark:bg-sky-950/40 font-bold text-sky-700 dark:text-sky-300'
                : 'border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300'
            }`}
          >
            <div className="flex items-center gap-3">
              <span className="text-xl">🇸🇦</span>
              <div>
                <div>العربية (Arabic)</div>
                <div className="text-[11px] text-slate-400 font-normal">اللغة الافتراضية والفوترة الضريبية</div>
              </div>
            </div>
            {selectedLang === 'ar' && <Check className="w-5 h-5 text-sky-600" />}
          </button>

          <button
            onClick={() => setSelectedLang('en')}
            className={`w-full p-3.5 rounded-2xl border text-right transition cursor-pointer flex items-center justify-between ${
              selectedLang === 'en'
                ? 'border-sky-500 bg-sky-50 dark:bg-sky-950/40 font-bold text-sky-700 dark:text-sky-300'
                : 'border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300'
            }`}
          >
            <div className="flex items-center gap-3">
              <span className="text-xl">🇬🇧</span>
              <div>
                <div>English (الإنجليزية)</div>
                <div className="text-[11px] text-slate-400 font-normal">PMS Hotel Interface (EN)</div>
              </div>
            </div>
            {selectedLang === 'en' && <Check className="w-5 h-5 text-sky-600" />}
          </button>
        </div>

        {/* Footer */}
        <div className="flex items-center gap-3 pt-2">
          <button
            onClick={() => {
              setIsLanguageModalOpen(false);
            }}
            className="flex-1 py-2.5 rounded-xl bg-sky-600 hover:bg-sky-500 text-white font-semibold text-xs shadow-md transition cursor-pointer"
          >
            تطبيق وحفظ
          </button>
          <button
            onClick={() => setIsLanguageModalOpen(false)}
            className="px-4 py-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 text-xs font-medium hover:bg-slate-200 transition cursor-pointer"
          >
            إلغاء
          </button>
        </div>
      </div>
    </div>
  );
};
